<?php
session_start();
require_once 'config/database.php';

if(isset($_POST['register'])) {
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Email validation
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error'] = "Please enter a valid email address with @ symbol.";
    }
    // Password length validation
    else if (strlen($password) < 8) {
        $_SESSION['error'] = "Password must be at least 8 characters long.";
    }
    // Password match validation
    else if($password !== $confirm_password) {
        $_SESSION['error'] = "Passwords do not match. Please try again.";
    } else {
        // Check if email already exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if($stmt->rowCount() > 0) {
            $_SESSION['error'] = "This email is already registered. Please use a different email or login instead.";
        } else {
            // Insert new user
            $stmt = $pdo->prepare("INSERT INTO users (fullname, email, password) VALUES (?, ?, ?)");
            if($stmt->execute([$fullname, $email, $password])) {
                $_SESSION['success'] = "<i class='fas fa-check-circle text-green-500 mr-2'></i>Registration successful! Welcome to Expense Manager. Please login to continue.";
                header("Location: login.php");
                exit();
            } else {
                $_SESSION['error'] = "Registration failed. Please try again later.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="image/icon.png">
    <title>Register - Expense Manager</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="assets/css/style.css" rel="stylesheet">
    <style>
        /* Remove any custom password reveal/clear button styles */
        input[type="password"]::-ms-reveal,
        input[type="password"]::-ms-clear {
            display: none;
        }
        
        /* Reset any webkit specific styles */
        input[type="password"] {
            -webkit-text-security: disc;
        }

        /* Ensure password fields show browser's reveal button */
        input[type="password"]::-webkit-credentials-auto-fill-button,
        input[type="password"]::-webkit-contacts-auto-fill-button {
            visibility: hidden;
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <!-- Logo Section -->
    <div class="text-center pt-8">
        <a href="index.php" class="inline-flex items-center text-2xl font-bold text-indigo-600">
            <img src="image/logo.png" alt="Logo" class="h-8 w-auto mr-2">Expense Manager
        </a>
    </div>

    <!-- Registration Form -->
    <div class="flex-grow container mx-auto px-4 flex items-center justify-center">
        <div class="max-w-md w-full bg-white rounded-lg shadow-lg p-8 m-4">
            <h2 class="text-2xl font-bold text-center mb-8">Create Your Account</h2>
            
            <?php if(isset($error)): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="" class="space-y-6">
                <div>
                    <label class="block text-gray-700 mb-2" for="fullname">Full Name</label>
                    <input type="text" id="fullname" name="fullname" required
                        class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-indigo-500"
                        placeholder="Enter your full name">
                </div>

                <div>
                    <label class="block text-gray-700 mb-2" for="email">Email Address</label>
                    <input type="email" id="email" name="email" required
                        pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$"
                        class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-indigo-500"
                        placeholder="Enter your email"
                        title="Please include an @ in the email address">
                </div>

                <div>
                    <label class="block text-gray-700 mb-2" for="password">Password</label>
                    <div class="relative">
                        <input type="password" 
                               id="password" 
                               name="password" 
                               required
                               minlength="8"
                               class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-indigo-500 pr-10"
                               placeholder="Create a password (min. 8 characters)"
                               title="Password must be at least 8 characters long">
                        <button type="button" 
                                class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 focus:outline-none"
                                onclick="togglePasswordVisibility('password', 'passwordIcon')">
                            <i id="passwordIcon" class="fas fa-eye"></i>
                        </button>
                        <p class="text-xs text-gray-500 mt-1">Must be at least 8 characters long</p>
                    </div>
                </div>

                <div>
                    <label class="block text-gray-700 mb-2" for="confirm_password">Confirm Password</label>
                    <div class="relative">
                        <input type="password" 
                               id="confirm_password" 
                               name="confirm_password" 
                               required
                               minlength="8"
                               class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-indigo-500 pr-10"
                               placeholder="Confirm your password">
                        <button type="button" 
                                class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 focus:outline-none"
                                onclick="togglePasswordVisibility('confirm_password', 'confirmPasswordIcon')">
                            <i id="confirmPasswordIcon" class="fas fa-eye"></i>
                        </button>
                        <div class="absolute right-12 top-1/2 transform -translate-y-1/2">
                            <i id="passwordMatchIcon" class="fas fa-times text-red-500 hidden"></i>
                        </div>
                        <p id="passwordMatchText" class="text-xs mt-1"></p>
                    </div>
                </div>

                <button type="submit" name="register"
                    class="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition duration-300">
                    <i class="fas fa-user-plus mr-2"></i>Register
                </button>
            </form>

            <p class="text-center mt-6">
                Already have an account? 
                <a href="login.php" class="text-indigo-600 hover:text-indigo-800">Login here</a>
            </p>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
</body>
<script>
    function togglePasswordVisibility(inputId, iconId) {
        const input = document.getElementById(inputId);
        const icon = document.getElementById(iconId);
        
        if (input.type === 'password') {
            input.type = 'text';
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
        } else {
            input.type = 'password';
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        const form = document.querySelector('form');
        const password = document.getElementById('password');
        const confirmPassword = document.getElementById('confirm_password');
        const email = document.getElementById('email');
        const matchIcon = document.getElementById('passwordMatchIcon');
        const matchText = document.getElementById('passwordMatchText');

        function checkPasswordMatch() {
            if (confirmPassword.value === '') {
                matchIcon.classList.add('hidden');
                matchText.textContent = '';
                confirmPassword.classList.remove('border-red-500', 'border-green-500');
                return;
            }

            if (password.value === confirmPassword.value) {
                matchIcon.classList.remove('fa-times', 'text-red-500', 'hidden');
                matchIcon.classList.add('fa-check', 'text-green-500');
                matchText.textContent = 'Passwords match';
                matchText.classList.remove('text-red-500');
                matchText.classList.add('text-green-500');
                confirmPassword.classList.remove('border-red-500');
                confirmPassword.classList.add('border-green-500');
            } else {
                matchIcon.classList.remove('fa-check', 'text-green-500', 'hidden');
                matchIcon.classList.add('fa-times', 'text-red-500');
                matchText.textContent = 'Passwords do not match';
                matchText.classList.remove('text-green-500');
                matchText.classList.add('text-red-500');
                confirmPassword.classList.remove('border-green-500');
                confirmPassword.classList.add('border-red-500');
            }
        }

        // Check passwords match in real-time
        confirmPassword.addEventListener('input', checkPasswordMatch);
        password.addEventListener('input', function() {
            if (confirmPassword.value !== '') {
                checkPasswordMatch();
            }
        });

        // Form validation
        form.addEventListener('submit', function(e) {
            if (password.value.length < 8) {
                e.preventDefault();
                alert('Password must be at least 8 characters long');
                password.focus();
                return;
            }

            if (password.value !== confirmPassword.value) {
                e.preventDefault();
                alert('Passwords do not match');
                confirmPassword.focus();
                return;
            }

            if (!email.value.includes('@')) {
                e.preventDefault();
                alert('Please include an @ in the email address');
                email.focus();
                return;
            }
        });

        // Real-time validations
        confirmPassword.addEventListener('input', function() {
            if (password.value !== confirmPassword.value) {
                confirmPassword.setCustomValidity('Passwords do not match');
            } else {
                confirmPassword.setCustomValidity('');
            }
        });

        password.addEventListener('input', function() {
            if (password.value.length < 8) {
                password.setCustomValidity('Password must be at least 8 characters long');
            } else {
                password.setCustomValidity('');
                if (confirmPassword.value) {
                    if (password.value !== confirmPassword.value) {
                        confirmPassword.setCustomValidity('Passwords do not match');
                    } else {
                        confirmPassword.setCustomValidity('');
                    }
                }
            }
        });
    });
</script>
</html>
