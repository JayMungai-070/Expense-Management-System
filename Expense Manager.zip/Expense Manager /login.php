<?php
session_start();
require_once 'config/database.php';

if(isset($_POST['login'])) {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if($user && $password == $user['password']) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['fullname'] = $user['fullname'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['profile_picture'] = $user['profile_picture'];
        
        $_SESSION['success'] = "<i class='fas fa-check-circle text-green-500 mr-2'></i>Welcome back, {$user['fullname']}! You have successfully logged in to your account.";
        header("Location: dashboard.php");
        exit();
    } else {
        if (!$user) {
            $_SESSION['error'] = "<i class='fas fa-exclamation-circle mr-2'></i>No account found with this email. Please <a href='register.php' class='text-indigo-600 hover:underline'>register here</a>.";
        } else {
            $_SESSION['error'] = "<i class='fas fa-exclamation-circle mr-2'></i>Incorrect password. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="image/icon.png">
    <title>Login - Expense Manager</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link href="assets/css/style.css" rel="stylesheet">
    <style>
        .notification-toast {
            animation: slideDown 0.5s ease-out;
        }
        @keyframes slideDown {
            from { transform: translateY(-100%); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <?php if(isset($_SESSION['error']) || isset($_SESSION['success'])): ?>
        <div id="notifications-container" class="fixed top-4 right-4 z-50 space-y-4 min-w-[300px]">
            <?php if(isset($_SESSION['success'])): ?>
                <div class="notification-toast bg-white border-l-4 border-green-500 rounded-lg shadow-lg p-4 mb-4 animate__animated animate__fadeInRight">
                    <div class="flex items-center">
                        <div class="flex-1">
                            <?php echo $_SESSION['success']; ?>
                        </div>
                        <button onclick="this.closest('.notification-toast').remove()" class="ml-4">
                            <i class="fas fa-times text-gray-400 hover:text-gray-500"></i>
                        </button>
                    </div>
                </div>
                <?php unset($_SESSION['success']); ?>
            <?php endif; ?>

            <?php if(isset($_SESSION['error'])): ?>
                <div class="notification-toast bg-white border-l-4 border-red-500 rounded-lg shadow-lg p-4 mb-4 animate__animated animate__fadeInRight">
                    <div class="flex items-center">
                        <div class="flex-1">
                            <?php echo $_SESSION['error']; ?>
                        </div>
                        <button onclick="this.closest('.notification-toast').remove()" class="ml-4">
                            <i class="fas fa-times text-gray-400 hover:text-gray-500"></i>
                        </button>
                    </div>
                </div>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>
        </div>

        <script>
        document.addEventListener('DOMContentLoaded', function() {
            const notifications = document.querySelectorAll('.notification-toast');
            notifications.forEach(notification => {
                setTimeout(() => {
                    notification.classList.add('animate__fadeOutRight');
                    setTimeout(() => {
                        notification.remove();
                    }, 500);
                }, 5000);
            });
        });
        </script>
    <?php endif; ?>
    <!-- Logo Section -->
    <div class="text-center pt-8">
        <a href="index.php" class="inline-flex items-center text-2xl font-bold text-indigo-600">
            <img src="image/logo.png" alt="Logo" class="h-8 w-auto mr-2">Expense Manager
        </a>
    </div>

    <!-- Login Form -->
    <div class="flex-grow container mx-auto px-4 flex items-center justify-center">
        <div class="max-w-md w-full bg-white rounded-lg shadow-lg p-8 m-4">
            <h2 class="text-2xl font-bold text-center mb-8">Login to Your Account</h2>
            
            <?php if(isset($error)): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="" class="space-y-6">
                <div>
                    <label class="block text-gray-700 mb-2" for="email">Email Address</label>
                    <input type="email" id="email" name="email" required
                        class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-indigo-500"
                        placeholder="Enter your email">
                </div>

                <div>
                    <label class="block text-gray-700 mb-2" for="password">Password</label>
                    <div class="relative">
                        <input type="password" id="password" name="password" required
                            class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-indigo-500 pr-10"
                            placeholder="Enter your password">
                    </div>
                </div>

                <button type="submit" name="login"
                    class="w-full bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition duration-300">
                    <i class="fas fa-sign-in-alt mr-2"></i>Login
                </button>
            </form>

            <p class="text-center mt-6">
                Don't have an account? 
                <a href="register.php" class="text-indigo-600 hover:text-indigo-800">Register here</a>
            </p>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
</body>
<script>
    // Keep track of password visibility state
    let passwordVisible = false;

    // Function to toggle password visibility
    function togglePasswordVisibility(inputId, iconId) {
        const input = document.getElementById(inputId);
        const icon = document.getElementById(iconId);
        
        if (input.type === 'password') {
            input.type = 'text';
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
        } else {
            input.type = 'password';
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
        }
    }

    // Update the password input field to include the eye icon
    document.addEventListener('DOMContentLoaded', function() {
        // Update password field
        const passwordField = document.getElementById('password');
        const passwordWrapper = passwordField.parentElement;
        passwordWrapper.classList.add('relative');
        passwordField.insertAdjacentHTML('afterend', `
            <button type="button" id="togglePassword" 
                    class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 focus:outline-none"
                    onclick="togglePasswordVisibility('password', 'passwordIcon')">
                <i id="passwordIcon" class="fas fa-eye"></i>
            </button>
        `);

        // Update input padding to prevent text overlap with icon
        passwordField.classList.add('pr-10');
    });
</script>
</html>
