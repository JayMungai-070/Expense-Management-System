<?php
session_start();
require_once 'config/database.php';

if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$page_title = "Profile Settings";
$current_page = "profile";

// Handle profile updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profile'])) {
        $fullname = !empty($_POST['fullname']) ? trim($_POST['fullname']) : $_SESSION['fullname'];
        $email = !empty($_POST['email']) ? trim($_POST['email']) : $_SESSION['email'];
        $password = !empty($_POST['password']) ? trim($_POST['password']) : $user['password'];
        $hasChanges = false;
        $errors = [];

        // Validate email if changed
        if ($email !== $_SESSION['email']) {
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = "Invalid email format. Email must contain @";
            }
        }

        // Validate password if changed
        if ($password !== $user['password']) {
            if (strlen($password) < 8) {
                $errors[] = "Password must be at least 8 characters long";
            }
        }

        if (empty($errors)) {
            try {
                // Only update user information if there are changes
                if ($fullname !== $_SESSION['fullname'] || $email !== $_SESSION['email'] || $password !== $user['password']) {
                    $stmt = $pdo->prepare("UPDATE users SET fullname = ?, email = ?, password = ? WHERE id = ?");
                    $stmt->execute([$fullname, $email, $password, $_SESSION['user_id']]);
                    $hasChanges = true;
                }

                // Handle profile picture upload separately
                if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === 0) {
                    $allowed = ['jpg', 'jpeg', 'png', 'gif'];
                    $filename = $_FILES['profile_picture']['name'];
                    $filesize = $_FILES['profile_picture']['size'];
                    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

                    if (!in_array($ext, $allowed)) {
                        $_SESSION['error'] = "<i class='fas fa-exclamation-circle mr-2'></i>Invalid file type. Please upload JPG, PNG, or GIF files only.";
                    } elseif ($filesize > 2 * 1024 * 1024) {
                        $_SESSION['error'] = "<i class='fas fa-exclamation-circle mr-2'></i>File size too large. Maximum size is 2MB.";
                    } else {
                        $new_filename = uniqid() . '.' . $ext;
                        $upload_path = 'uploads/profile/' . $new_filename;

                        if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $upload_path)) {
                            // Delete old profile picture if it exists and is not default
                            if ($user['profile_picture'] && $user['profile_picture'] != 'default.jpg') {
                                $old_file = 'uploads/profile/' . $user['profile_picture'];
                                if (file_exists($old_file)) {
                                    unlink($old_file);
                                }
                            }

                            // Update profile picture in database
                            $stmt = $pdo->prepare("UPDATE users SET profile_picture = ? WHERE id = ?");
                            $stmt->execute([$new_filename, $_SESSION['user_id']]);
                            $_SESSION['profile_picture'] = $new_filename;
                            $hasChanges = true;
                        }
                    }
                }

                if ($hasChanges) {
                    $_SESSION['success'] = "<i class='fas fa-check-circle text-green-500 mr-2'></i>Your profile has been successfully updated.";
                    $_SESSION['fullname'] = $fullname;
                    $_SESSION['email'] = $email;
                }
            } catch(PDOException $e) {
                $_SESSION['error'] = "Error updating profile: " . $e->getMessage();
            }
        } else {
            $_SESSION['error'] = implode("<br>", $errors);
        }
        
        header("Location: profile.php");
        exit();
    }
}

// Fetch user data
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

require_once 'includes/header.php';
?>

<div class="p-6 space-y-6 animate__animated animate__fadeIn">
    <div class="max-w-4xl mx-auto">
        <!-- Profile Header -->
        <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
            <div class="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-6">
                <div class="relative">
                    <img src="uploads/profile/<?php echo $user['profile_picture'] ?: 'default.png'; ?>" 
                         alt="Profile Picture" 
                         class="w-32 h-32 rounded-full border-4 border-indigo-600 object-cover">
                </div>
                <div class="text-center md:text-left">
                    <h2 class="text-2xl font-bold text-gray-800"><?php echo htmlspecialchars($user['fullname']); ?></h2>
                    <p class="text-gray-600"><?php echo htmlspecialchars($user['email']); ?></p>
                    <p class="text-sm text-gray-500">Member since <?php echo date('F Y', strtotime($user['created_at'])); ?></p>
                </div>
            </div>
        </div>

        <!-- Profile Form -->
        <div class="bg-white rounded-lg shadow-lg overflow-hidden">
            <div class="p-6 border-b">
                <h3 class="text-lg font-bold">Edit Profile</h3>
            </div>
            <form method="POST" enctype="multipart/form-data" class="p-6 space-y-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                    <input type="text" name="fullname" value="<?php echo htmlspecialchars($user['fullname']); ?>" required
                           class="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all duration-300">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                    <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required
                           class="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all duration-300">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Password</label>
                    <div class="relative">
                        <input type="password" name="password" id="password" value="<?php echo htmlspecialchars($user['password']); ?>"
                               class="w-full border rounded-lg px-4 py-2 pr-10 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all duration-300"
                               minlength="8">
                        <button type="button" 
                                class="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-500 cursor-pointer"
                                onclick="togglePasswordVisibility()">
                            <i class="fas fa-eye" id="togglePassword"></i>
                        </button>
                    </div>
                    <p class="text-sm text-gray-500 mt-1">Minimum 8 characters required</p>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Profile Picture</label>
                    <div class="mt-1 flex items-center space-x-4">
                        <label class="relative cursor-pointer bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors duration-300">
                            <span><i class="fas fa-upload mr-2"></i>Choose File</span>
                            <input type="file" name="profile_picture" class="hidden" accept="image/*">
                        </label>
                        <span class="text-sm text-gray-500">JPG, PNG, or GIF (Max. 2MB)</span>
                    </div>
                </div>

                <div class="flex justify-end">
                    <button type="submit" name="update_profile" 
                            class="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transform hover:scale-105 transition-all duration-300 flex items-center">
                        <i class="fas fa-save mr-2"></i>
                        Save Changes
                    </button>
                </div>
            </form>
        </div>

        <!-- Account Statistics -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
            <!-- Total Expenses Count -->
            <div class="bg-white rounded-lg shadow-lg p-6 transform hover:scale-105 transition-all duration-300">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm">Total Expenses</p>
                        <p class="text-2xl font-bold text-indigo-600">
                            <?php
                            $stmt = $pdo->prepare("SELECT COUNT(*) FROM expenses WHERE user_id = ?");
                            $stmt->execute([$_SESSION['user_id']]);
                            echo number_format($stmt->fetchColumn());
                            ?>
                        </p>
                    </div>
                    <div class="p-3 bg-indigo-100 rounded-full">
                        <i class="fas fa-receipt text-indigo-600 text-xl"></i>
                    </div>
                </div>
            </div>
        
            <!-- Categories Count -->
            <div class="bg-white rounded-lg shadow-lg p-6 transform hover:scale-105 transition-all duration-300">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm">Categories</p>
                        <p class="text-2xl font-bold text-green-600">
                            <?php
                            $stmt = $pdo->prepare("SELECT COUNT(*) FROM categories WHERE user_id = ?");
                            $stmt->execute([$_SESSION['user_id']]);
                            echo number_format($stmt->fetchColumn());
                            ?>
                        </p>
                    </div>
                    <div class="p-3 bg-green-100 rounded-full">
                        <i class="fas fa-tags text-green-600 text-xl"></i>
                    </div>
                </div>
            </div>
        
            <!-- Last Activity -->
            <div class="bg-white rounded-lg shadow-lg p-6 transform hover:scale-105 transition-all duration-300">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm">Last Activity</p>
                        <p class="text-xl font-bold text-blue-600">
                            <?php
                            $stmt = $pdo->prepare("
                                SELECT created_at 
                                FROM (
                                    SELECT created_at FROM expenses WHERE user_id = ?
                                    UNION ALL
                                    SELECT created_at FROM categories WHERE user_id = ?
                                ) AS combined
                                ORDER BY created_at DESC
                                LIMIT 1
                            ");
                            $stmt->execute([$_SESSION['user_id'], $_SESSION['user_id']]);
                            $last_activity = $stmt->fetchColumn();
                            echo $last_activity ? date('M d, Y', strtotime($last_activity)) : 'No activity';
                            ?>
                        </p>
                    </div>
                    <div class="p-3 bg-blue-100 rounded-full">
                        <i class="fas fa-clock text-blue-600 text-xl"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Update the profile picture preview script -->
<script>
function togglePasswordVisibility() {
    const passwordInput = document.getElementById('password');
    const toggleIcon = document.getElementById('togglePassword');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleIcon.classList.remove('fa-eye');
        toggleIcon.classList.add('fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        toggleIcon.classList.remove('fa-eye-slash');
        toggleIcon.classList.add('fa-eye');
    }
}

// Update the profile picture preview
document.querySelector('input[type="file"]').addEventListener('change', function(e) {
    if (e.target.files && e.target.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.querySelector('img.w-32').src = e.target.result;
            if (document.getElementById('headerProfilePic')) {
                document.getElementById('headerProfilePic').src = e.target.result;
            }
        }
        reader.readAsDataURL(e.target.files[0]);
    }
});
</script>

<?php require_once 'includes/footer.php'; ?>
