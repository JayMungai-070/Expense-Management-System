<?php
session_start();
require_once 'config/database.php';

if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$page_title = "Manage Expenses";
$current_page = "expenses";

// Fetch categories for dropdown
$stmt = $pdo->prepare("SELECT * FROM categories WHERE user_id = ? ORDER BY name");
$stmt->execute([$_SESSION['user_id']]);
$categories = $stmt->fetchAll();

// Handle expense operations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Add this function at the top of the file after database connection
    function checkDuplicateExpense($pdo, $amount, $description, $category_id, $expense_date, $user_id, $expense_id = null) {
        $params = [$amount, $description, $category_id, $expense_date, $user_id];
        $sql = "SELECT id FROM expenses WHERE amount = ? AND description = ? AND category_id = ? AND expense_date = ? AND user_id = ?";
        
        if ($expense_id) {
            $sql .= " AND id != ?";
            $params[] = $expense_id;
        }
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetch();
    }

    // Update the add expense handler
    if (isset($_POST['add_expense'])) {
        $amount = trim($_POST['amount']);
        $description = trim($_POST['description']);
        $category_id = $_POST['category_id'];
        $expense_date = $_POST['expense_date'];
    
        // Check for duplicate expense
        if (checkDuplicateExpense($pdo, $amount, $description, $category_id, $expense_date, $_SESSION['user_id'])) {
            $_SESSION['error'] = "<i class='fas fa-exclamation-circle mr-2'></i>An identical expense already exists.";
        } else {
            try {
                $stmt = $pdo->prepare("INSERT INTO expenses (amount, description, category_id, expense_date, user_id) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$amount, $description, $category_id, $expense_date, $_SESSION['user_id']]);
                $_SESSION['success'] = "<i class='fas fa-check-circle text-green-500 mr-2'></i>Expense has been successfully added.";
            } catch(PDOException $e) {
                $_SESSION['error'] = "<i class='fas fa-exclamation-circle mr-2'></i>Error adding expense: " . $e->getMessage();
            }
        }
        header("Location: expenses.php");
        exit();
    }

    // Add edit expense handler
    if (isset($_POST['edit_expense'])) {
        $expense_id = $_POST['expense_id'];
        $amount = trim($_POST['amount']);
        $description = trim($_POST['description']);
        $category_id = $_POST['category_id'];
        $expense_date = $_POST['expense_date'];
    
        // Check for duplicate expense excluding current expense
        if (checkDuplicateExpense($pdo, $amount, $description, $category_id, $expense_date, $_SESSION['user_id'], $expense_id)) {
            $_SESSION['error'] = "<i class='fas fa-exclamation-circle mr-2'></i>An identical expense already exists.";
        } else {
            try {
                $stmt = $pdo->prepare("UPDATE expenses SET amount = ?, description = ?, category_id = ?, expense_date = ? WHERE id = ? AND user_id = ?");
                $stmt->execute([$amount, $description, $category_id, $expense_date, $expense_id, $_SESSION['user_id']]);
                $_SESSION['success'] = "<i class='fas fa-check-circle text-green-500 mr-2'></i>Expense has been successfully updated.";
            } catch(PDOException $e) {
                $_SESSION['error'] = "<i class='fas fa-exclamation-circle mr-2'></i>Error updating expense: " . $e->getMessage();
            }
        }
        header("Location: expenses.php");
        exit();
    }

    if (isset($_POST['delete_expense'])) {
        $expense_id = $_POST['expense_id'];
        try {
            $stmt = $pdo->prepare("DELETE FROM expenses WHERE id = ? AND user_id = ?");
            $stmt->execute([$expense_id, $_SESSION['user_id']]);
            $_SESSION['success'] = "<i class='fas fa-check-circle text-green-500 mr-2'></i>Expense has been successfully deleted.";
        } catch(PDOException $e) {
            $_SESSION['error'] = "Error deleting expense: " . $e->getMessage();
        }
        header("Location: expenses.php");
        exit();
    }
}

// Pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Get search term
$search_term = isset($_GET['search']) ? trim($_GET['search']) : '';

// Base query for total count
$countSql = "SELECT COUNT(*) FROM expenses e LEFT JOIN categories c ON e.category_id = c.id WHERE e.user_id = ?";
$searchParams = [$_SESSION['user_id']];

// Main query for fetching expenses
$sql = "SELECT e.*, c.name as category_name, COALESCE(c.color, '#4F46E5') as category_color 
        FROM expenses e 
        LEFT JOIN categories c ON e.category_id = c.id 
        WHERE e.user_id = ?";

// Add search conditions if search term exists
if ($search_term) {
    $searchCondition = " AND (
        e.description LIKE ? OR 
        e.amount LIKE ? OR 
        c.name LIKE ? OR 
        DATE_FORMAT(e.expense_date, '%M %d, %Y') LIKE ? OR
        DATE_FORMAT(e.expense_date, '%Y-%m-%d') LIKE ?
    )";
    $countSql .= $searchCondition;
    $sql .= $searchCondition;
    
    $searchTerm = "%{$search_term}%";
    $searchParams = array_merge($searchParams, [$searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm]);
}

$sql .= " ORDER BY e.expense_date DESC LIMIT ?, ?";

// Get total filtered count
$stmt = $pdo->prepare($countSql);
$stmt->execute($searchParams);
$total_expenses = $stmt->fetchColumn();
$total_pages = ceil($total_expenses / $limit);

// Execute main query with pagination
$stmt = $pdo->prepare($sql);
$finalParams = array_merge($searchParams, [$offset, $limit]);
foreach($finalParams as $i => $param) {
    $stmt->bindValue($i + 1, $param, is_int($param) ? PDO::PARAM_INT : PDO::PARAM_STR);
}
$stmt->execute();
$expenses = $stmt->fetchAll();

require_once 'includes/header.php';
?>

<!-- Add Expense Button and Search -->
<div class="p-6 flex flex-col sm:flex-row justify-between items-center gap-4">
    <button onclick="openAddExpenseModal()" 
            class="bg-indigo-600 text-white px-6 py-3 rounded-lg shadow-lg hover:bg-indigo-700 transform hover:scale-105 transition-all duration-300 flex items-center">
        <i class="fas fa-plus-circle mr-2 animate__animated animate__rotateIn"></i>
        Add New Expense
    </button>
    
    <input type="text" 
           id="searchExpense" 
           placeholder="Search expenses..." 
           class="w-full sm:w-96 border rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500">
</div>

<!-- Expenses List -->
<div class="p-6 space-y-6">
    <div class="bg-white rounded-lg shadow-lg overflow-hidden">
        <div class="p-6 border-b">
            <h2 class="text-xl font-bold flex items-center">
                <i class="fas fa-list-alt mr-2 text-indigo-600"></i>
                Expenses List
            </h2>
        </div>

        <?php if (!empty($expenses)): ?>
            <div class="divide-y">
                <?php foreach($expenses as $expense): ?>
                    <!-- Update expense item layout -->
                    <div class="p-4 hover:bg-gray-50 transition-all duration-300" data-category-id="<?php echo $expense['category_id']; ?>">
                        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                            <div class="flex items-center space-x-4">
                                <div class="p-3 rounded-full" style="background-color: <?php echo htmlspecialchars($expense['category_color']); ?>20">
                                    <i class="fas fa-receipt" style="color: <?php echo htmlspecialchars($expense['category_color']); ?>"></i>
                                </div>
                                <div>
                                    <p class="font-semibold text-lg"><?php echo htmlspecialchars($expense['description']); ?></p>
                                    <p class="text-sm text-gray-500">
                                        <i class="fas fa-tag mr-1" style="color: <?php echo htmlspecialchars($expense['category_color']); ?>"></i>
                                        <?php echo htmlspecialchars($expense['category_name']); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="flex items-center justify-between sm:justify-end w-full sm:w-auto gap-4">
                                <div class="text-right">
                                    <p class="font-bold text-red-600 text-lg">-$<?php echo number_format($expense['amount'], 2); ?></p>
                                    <p class="text-sm text-gray-500">
                                        <i class="far fa-calendar-alt mr-1"></i>
                                        <?php echo date('M d, Y', strtotime($expense['expense_date'])); ?>
                                    </p>
                                </div>
                                <div class="flex space-x-2">
                                    <button onclick="editExpense(<?php echo htmlspecialchars(json_encode($expense)); ?>)" 
                                            class="text-blue-600 hover:text-blue-800 transition-colors duration-300">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button type="button" 
                                            class="delete-expense-btn text-red-600 hover:text-red-800 transition-colors duration-300"
                                            data-expense-id="<?php echo $expense['id']; ?>">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Updated Pagination -->
            <div class="p-4 bg-gray-50 flex justify-center space-x-2">
                <?php if ($page > 1): ?>
                    <a href="?page=1<?php echo $search_term ? '&search=' . urlencode($search_term) : ''; ?>" 
                       class="px-4 py-2 bg-white border border-gray-300 rounded-lg text-indigo-600 hover:bg-indigo-50">
                        <i class="fas fa-angle-double-left"></i>
                    </a>
                    <a href="?page=<?php echo ($page - 1) . ($search_term ? '&search=' . urlencode($search_term) : ''); ?>" 
                       class="px-4 py-2 bg-white border border-gray-300 rounded-lg text-indigo-600 hover:bg-indigo-50">
                        <i class="fas fa-angle-left"></i>
                    </a>
                <?php endif; ?>

                <span class="px-4 py-2 bg-indigo-600 text-white rounded-lg">
                    Page <?php echo $page; ?> of <?php echo $total_pages; ?>
                </span>

                <?php if ($page < $total_pages): ?>
                    <a href="?page=<?php echo ($page + 1) . ($search_term ? '&search=' . urlencode($search_term) : ''); ?>" 
                       class="px-4 py-2 bg-white border border-gray-300 rounded-lg text-indigo-600 hover:bg-indigo-50">
                        <i class="fas fa-angle-right"></i>
                    </a>
                    <a href="?page=<?php echo $total_pages . ($search_term ? '&search=' . urlencode($search_term) : ''); ?>" 
                       class="px-4 py-2 bg-white border border-gray-300 rounded-lg text-indigo-600 hover:bg-indigo-50">
                        <i class="fas fa-angle-double-right"></i>
                    </a>
                <?php endif; ?>
            </div>
            
            <?php else: ?>
            <div class="p-6 text-center text-gray-500">
                <i class="fas fa-receipt text-6xl mb-4 animate__animated animate__pulse infinite"></i>
                <p class="text-xl">No expenses found</p>
                <p class="text-sm">Start adding your expenses to track them</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Add/Edit Expense Modal -->
<div id="expenseModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
    <div class="flex items-center justify-center min-h-screen p-4">
        <div class="bg-white rounded-lg shadow-xl w-full max-w-md transform transition-all duration-300 scale-95 opacity-0" id="modalContent">
            <div class="p-6">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-xl font-bold" id="modalTitle">Add New Expense</h3>
                    <button onclick="closeExpenseModal()" class="text-gray-400 hover:text-gray-600">
                        <i class="fas fa-times"></i>
                    </button>
                </div>

                <form method="POST" class="space-y-4" id="expenseForm">
                    <input type="hidden" name="expense_id" id="expense_id">
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Amount</label>
                        <div class="relative">
                            <span class="absolute left-3 top-2 text-gray-500">$</span>
                            <input type="number" step="0.01" name="amount" id="amount" required
                                   class="pl-8 w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Description</label>
                        <input type="text" name="description" id="description" required
                               class="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Category</label>
                        <select name="category_id" id="category_id" required
                                class="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                            <?php foreach($categories as $category): ?>
                                <option value="<?php echo $category['id']; ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Date</label>
                        <input type="date" name="expense_date" id="expense_date" required
                               value="<?php echo date('Y-m-d'); ?>"
                               class="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>

                    <div class="flex justify-end space-x-3">
                        <button type="button" onclick="closeExpenseModal()"
                                class="px-4 py-2 border rounded-lg hover:bg-gray-100 transition-colors duration-300">
                            Cancel
                        </button>
                        <button type="submit" id="submitBtn" name="add_expense"
                                class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors duration-300">
                            Save Expense
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Add this delete confirmation modal after your existing modals -->
<div id="deleteExpenseModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
    <div class="flex items-center justify-center min-h-screen p-4">
        <div class="bg-white rounded-lg shadow-xl w-full max-w-md transform transition-all duration-300 scale-95 opacity-0" id="deleteExpenseModalContent">
            <div class="p-6">
                <div class="flex items-center mb-4">
                    <div class="rounded-full bg-red-100 p-3 mr-4">
                        <i class="fas fa-exclamation-triangle text-red-600 text-xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900">Delete Expense</h3>
                </div>
                <p class="text-gray-600 mb-4">Are you sure you want to delete this expense? This action cannot be undone.</p>
                <form id="deleteExpenseForm" method="POST" class="flex justify-end space-x-3">
                    <input type="hidden" name="expense_id" id="delete_expense_id">
                    <button type="button" onclick="closeDeleteExpenseModal()" 
                            class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors duration-200">
                        Cancel
                    </button>
                    <button type="submit" name="delete_expense"
                            class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors duration-200">
                        Delete Expense
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function openAddExpenseModal() {
    document.getElementById('expenseModal').classList.remove('hidden');
    setTimeout(() => {
        document.getElementById('modalContent').classList.remove('scale-95', 'opacity-0');
        document.getElementById('modalContent').classList.add('scale-100', 'opacity-100');
    }, 10);
}

function closeExpenseModal() {
    document.getElementById('modalContent').classList.add('scale-95', 'opacity-0');
    document.getElementById('modalContent').classList.remove('scale-100', 'opacity-100');
    setTimeout(() => {
        document.getElementById('expenseModal').classList.add('hidden');
    }, 300);
}

function confirmDelete() {
    return new Promise((resolve) => {
        const confirmed = confirm('Are you sure you want to delete this expense?');
        resolve(confirmed);
    });
}

// Update delete button handler
document.querySelectorAll('form[onsubmit]').forEach(form => {
    form.onsubmit = async (e) => {
        e.preventDefault();
        if (await confirmDelete()) {
            form.submit();
        }
    };
});

function editExpense(expense) {
    document.getElementById('modalTitle').textContent = 'Edit Expense';
    document.getElementById('expense_id').value = expense.id;
    document.getElementById('amount').value = expense.amount;
    document.getElementById('description').value = expense.description;
    document.getElementById('category_id').value = expense.category_id;
    document.getElementById('expense_date').value = expense.expense_date;
    
    // Update form submission type
    const submitBtn = document.getElementById('submitBtn');
    submitBtn.name = 'edit_expense';
    submitBtn.textContent = 'Update Expense';
    
    openAddExpenseModal();
}

// Update the search functionality
document.getElementById('searchExpense').addEventListener('input', function(e) {
    const searchTerm = e.target.value.toLowerCase();
    const currentUrl = new URL(window.location.href);
    
    if (searchTerm) {
        currentUrl.searchParams.set('search', searchTerm);
    } else {
        currentUrl.searchParams.delete('search');
    }
    
    // Reset to first page when searching
    currentUrl.searchParams.delete('page');
    
    // Use history.pushState to update URL without reload
    history.pushState({}, '', currentUrl);
    
    // Fetch and update results
    fetch(currentUrl)
        .then(response => response.text())
        .then(html => {
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');
            const expensesContainer = document.querySelector('.divide-y');
            const paginationContainer = document.querySelector('.bg-gray-50.flex.justify-center');
            
            if (!doc.querySelector('.divide-y div')) {
                // Show no results message with the same style as categories.php
                expensesContainer.innerHTML = `
                    <div class="col-span-full text-center p-8">
                        <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 mb-4">
                            <i class="fas fa-receipt text-4xl text-gray-400"></i>
                        </div>
                        <h3 class="text-lg font-semibold text-gray-900 mb-2">No expenses found</h3>
                        <p class="text-gray-500">Try adjusting your search terms or add a new expense</p>
                    </div>
                `;
                if (paginationContainer) {
                    paginationContainer.style.display = 'none';
                }
            } else {
                expensesContainer.innerHTML = doc.querySelector('.divide-y').innerHTML;
                if (paginationContainer) {
                    paginationContainer.style.display = 'flex';
                    paginationContainer.innerHTML = doc.querySelector('.bg-gray-50.flex.justify-center').innerHTML;
                }
            }
            
            // Reattach event listeners for delete and edit buttons
            attachEventListeners();
        });
});

// Add this function to reattach event listeners
function attachEventListeners() {
    // Reattach delete button handlers
    document.querySelectorAll('.delete-expense-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const expenseId = btn.dataset.expenseId;
            openDeleteExpenseModal(expenseId);
        });
    });
}

// Remove the old filterExpenses function as it's no longer needed
function filterExpenses(searchTerm) {
    const expenses = document.querySelectorAll('.divide-y > div');
    let hasVisibleExpenses = false;

    expenses.forEach(expense => {
        const description = expense.querySelector('.font-semibold')?.textContent.toLowerCase() || '';
        const categoryName = expense.querySelector('.text-sm.text-gray-500')?.textContent.toLowerCase() || '';
        const amount = expense.querySelector('.text-red-600')?.textContent.replace(/[^0-9.]/g, '') || '';
        const date = expense.querySelector('.far.fa-calendar-alt')?.parentElement?.textContent.toLowerCase() || '';
        
        const matchesSearch = !searchTerm || 
            description.includes(searchTerm) || 
            categoryName.includes(searchTerm) ||
            amount.includes(searchTerm) ||
            date.includes(searchTerm);

        if (matchesSearch) {
            expense.style.display = '';
            hasVisibleExpenses = true;
        } else {
            expense.style.display = 'none';
        }
    });

    // Show/hide no results message
    const noResultsDiv = document.getElementById('noSearchResults');
    if (!hasVisibleExpenses) {
        if (!noResultsDiv) {
            const message = `
                <div id="noSearchResults" class="p-6 text-center text-gray-500">
                    <i class="fas fa-search text-6xl mb-4"></i>
                    <p class="text-xl">No matching expenses found</p>
                    <p class="text-sm">Try adjusting your search terms (description, category, amount, or date)</p>
                </div>
            `;
            document.querySelector('.divide-y').insertAdjacentHTML('beforeend', message);
        }
    } else if (noResultsDiv) {
        noResultsDiv.remove();
    }
}

function openDeleteExpenseModal(expenseId) {
    const modal = document.getElementById('deleteExpenseModal');
    const modalContent = document.getElementById('deleteExpenseModalContent');
    
    document.getElementById('delete_expense_id').value = expenseId;
    
    modal.classList.remove('hidden');
    setTimeout(() => {
        modalContent.classList.remove('scale-95', 'opacity-0');
        modalContent.classList.add('scale-100', 'opacity-100');
    }, 10);
}

function closeDeleteExpenseModal() {
    const modal = document.getElementById('deleteExpenseModal');
    const modalContent = document.getElementById('deleteExpenseModalContent');
    
    modalContent.classList.remove('scale-100', 'opacity-100');
    modalContent.classList.add('scale-95', 'opacity-0');
    
    setTimeout(() => {
        modal.classList.add('hidden');
    }, 300);
}

// Update the delete button click handlers
document.querySelectorAll('.delete-expense-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
        e.preventDefault();
        const expenseId = btn.dataset.expenseId;
        openDeleteExpenseModal(expenseId);
    });
});

// Close modal when clicking outside
document.getElementById('deleteExpenseModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeDeleteExpenseModal();
    }
});

// Close modal on escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && !document.getElementById('deleteExpenseModal').classList.contains('hidden')) {
        closeDeleteExpenseModal();
    }
});
</script>

<?php require_once 'includes/footer.php'; ?>
