<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="image/icon.png">
    <title>Expense Manager - Welcome</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <!-- Logo Section -->
    <div class="text-center pt-8">
        <a href="index.php" class="inline-flex items-center text-2xl font-bold text-indigo-600">
            <img src="image/logo.png" alt="Logo" class="h-8 w-auto mr-2">Expense Manager
        </a>
    </div>

    <!-- Hero Section -->
    <div class="flex-grow container mx-auto px-4 py-16">
        <div class="text-center">
            <h1 class="text-4xl md:text-6xl font-bold text-indigo-600 mb-4">
                Manage Your Expenses Smartly
            </h1>
            <p class="text-xl text-gray-600 mb-8">
                Track, analyze, and control your expenses with our powerful expense management system
            </p>
            <div class="space-x-4">
                <a href="register.php" class="bg-indigo-600 text-white px-8 py-3 rounded-lg hover:bg-indigo-700 transition duration-300">
                    Get Started
                </a>
                <a href="login.php" class="bg-white text-indigo-600 px-8 py-3 rounded-lg border border-indigo-600 hover:bg-indigo-50 transition duration-300">
                    Login
                </a>
            </div>
        </div>
    </div>

    <!-- Features Section -->
    <div class="bg-white py-16">
        <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-12">Key Features</h2>
            <div class="grid md:grid-cols-3 gap-8">
                <div class="text-center p-6 hover:shadow-lg transition duration-300 rounded-lg">
                    <i class="fas fa-chart-line text-4xl text-indigo-600 mb-4"></i>
                    <h3 class="text-xl font-bold mb-2">Expense Tracking</h3>
                    <p class="text-gray-600">Track your daily expenses easily and efficiently</p>
                </div>
                <div class="text-center p-6 hover:shadow-lg transition duration-300 rounded-lg">
                    <i class="fas fa-tags text-4xl text-indigo-600 mb-4"></i>
                    <h3 class="text-xl font-bold mb-2">Category Management</h3>
                    <p class="text-gray-600">Organize expenses by categories</p>
                </div>
                <div class="text-center p-6 hover:shadow-lg transition duration-300 rounded-lg">
                    <i class="fas fa-file-alt text-4xl text-indigo-600 mb-4"></i>
                    <h3 class="text-xl font-bold mb-2">Detailed Reports</h3>
                    <p class="text-gray-600">Generate comprehensive expense reports</p>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
</body>
</html>
