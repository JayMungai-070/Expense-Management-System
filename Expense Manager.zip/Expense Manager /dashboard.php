<?php
session_start();
require_once 'config/database.php';

if(!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = "Please login to access the dashboard.";
    header("Location: login.php");
    exit();
}

// Quick Add Expense
if(isset($_POST['quick_add_expense'])) {
    $amount = trim($_POST['amount']);
    $description = trim($_POST['description']);
    $category_id = $_POST['category_id'];

    try {
        $stmt = $pdo->prepare("INSERT INTO expenses (amount, description, category_id, user_id, expense_date) VALUES (?, ?, ?, ?, NOW())");
        $stmt->execute([$amount, $description, $category_id, $_SESSION['user_id']]);
        $_SESSION['success'] = "Quick expense of $" . number_format($amount, 2) . " added successfully! <i class='fas fa-bolt animate__animated animate__bounceIn'></i>";
    } catch(PDOException $e) {
        $_SESSION['error'] = "Error adding quick expense: " . $e->getMessage();
    }
    header("Location: dashboard.php");
    exit();
}

// Update Dashboard Preferences
if(isset($_POST['update_preferences'])) {
    $chart_type = $_POST['chart_type'];
    $time_period = $_POST['time_period'];

    try {
        $stmt = $pdo->prepare("UPDATE user_preferences SET chart_type = ?, time_period = ? WHERE user_id = ?");
        $stmt->execute([$chart_type, $time_period, $_SESSION['user_id']]);
        $_SESSION['success'] = "Dashboard preferences updated successfully! <i class='fas fa-cog animate__animated animate__bounceIn'></i>";
    } catch(PDOException $e) {
        $_SESSION['error'] = "Error updating preferences: " . $e->getMessage();
    }
    header("Location: dashboard.php");
    exit();
}

$page_title = "Dashboard";
$current_page = "dashboard";

// Fetch user's total expenses with proper date range
$stmt = $pdo->prepare("
    SELECT 
        COALESCE(SUM(amount), 0) as total,
        COUNT(*) as count,
        MAX(expense_date) as latest_date,
        MIN(expense_date) as earliest_date,
        DATE_FORMAT(MAX(expense_date), '%M %d, %Y') as formatted_latest_date
    FROM expenses 
    WHERE user_id = ?
    AND expense_date >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY)
    AND expense_date <= CURRENT_DATE
");
$stmt->execute([$_SESSION['user_id']]);
$expense_stats = $stmt->fetch();

// Fetch recent expenses with proper joins and formatting
$stmt = $pdo->prepare("
    SELECT 
        e.*,
        c.name as category_name,
        c.color as category_color,
        DATE_FORMAT(e.expense_date, '%M %d, %Y') as formatted_date,
        DATE_FORMAT(e.created_at, '%h:%i %p') as formatted_time
    FROM expenses e 
    LEFT JOIN categories c ON e.category_id = c.id 
    WHERE e.user_id = ? 
    ORDER BY e.expense_date DESC, e.created_at DESC
    LIMIT 5
");
$stmt->execute([$_SESSION['user_id']]);
$recent_expenses = $stmt->fetchAll();

// Fetch top categories with accurate percentages
$stmt = $pdo->prepare("
    WITH TotalExpenses AS (
        SELECT COALESCE(SUM(amount), 0) as total
        FROM expenses
        WHERE user_id = ?
        AND expense_date >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY)
    )
    SELECT 
        c.id,
        c.name,
        c.color,
        COUNT(e.id) as expense_count,
        COALESCE(SUM(e.amount), 0) as total_amount,
        CASE 
            WHEN (SELECT total FROM TotalExpenses) > 0 
            THEN (SUM(COALESCE(e.amount, 0)) / (SELECT total FROM TotalExpenses) * 100)
            ELSE 0 
        END as percentage
    FROM categories c
    LEFT JOIN expenses e ON c.id = e.category_id 
        AND e.user_id = ? 
        AND e.expense_date >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY)
    WHERE c.user_id = ?
    GROUP BY c.id, c.name, c.color
    HAVING total_amount > 0
    ORDER BY total_amount DESC
    LIMIT 5
");
$stmt->execute([$_SESSION['user_id'], $_SESSION['user_id'], $_SESSION['user_id']]);
$top_categories = $stmt->fetchAll();

// Add monthly trend data
$stmt = $pdo->prepare("
    SELECT 
        DATE_FORMAT(expense_date, '%Y-%m') as month,
        SUM(amount) as total_amount,
        COUNT(*) as transaction_count
    FROM expenses
    WHERE user_id = ?
    AND expense_date >= DATE_SUB(CURRENT_DATE, INTERVAL 6 MONTH)
    GROUP BY DATE_FORMAT(expense_date, '%Y-%m')
    ORDER BY month DESC
");
$stmt->execute([$_SESSION['user_id']]);
$monthly_trends = $stmt->fetchAll();

// Add category distribution for current month
$stmt = $pdo->prepare("
    SELECT 
        c.name,
        c.color,
        COUNT(*) as count,
        SUM(e.amount) as total_amount,
        AVG(e.amount) as avg_amount
    FROM expenses e
    JOIN categories c ON e.category_id = c.id
    WHERE e.user_id = ?
    AND MONTH(e.expense_date) = MONTH(CURRENT_DATE)
    AND YEAR(e.expense_date) = YEAR(CURRENT_DATE)
    GROUP BY c.id, c.name, c.color
    ORDER BY total_amount DESC
");
$stmt->execute([$_SESSION['user_id']]);
$category_distribution = $stmt->fetchAll();

// Update the display of top category in the stats card
require_once 'includes/header.php';
?>

<div class="p-6 space-y-6 animate__animated animate__fadeIn">
    <!-- Welcome Message -->
    <div class="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-lg shadow-lg p-6 text-white transform hover:scale-[1.02] transition-transform duration-300">
        <div class="flex items-center justify-between">
            <div>
                <h2 class="text-2xl font-bold mb-2">Welcome back, <?php echo $_SESSION['fullname']; ?>!</h2>
                <p class="text-indigo-100">Here's your expense overview</p>
            </div>
            <div class="text-5xl">
                <i class="fas fa-chart-line"></i>
            </div>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <!-- Total Expenses Card -->
        <div class="bg-white rounded-lg shadow-md p-6 transform hover:scale-[1.02] transition-all duration-300">
            <div class="flex items-center">
                <div class="p-3 bg-indigo-100 rounded-full">
                    <i class="fas fa-money-bill-wave text-indigo-600 text-2xl"></i>
                </div>
                <div class="ml-4">
                    <h3 class="text-gray-500 text-sm">Total Expenses</h3>
                    <p class="text-2xl font-bold text-indigo-600">$<?php echo number_format($expense_stats['total'] ?? 0, 2); ?></p>
                    <p class="text-sm text-gray-500">
                        <?php echo $expense_stats['count'] ?? 0; ?> transactions
                    </p>
                </div>
            </div>
        </div>

        <!-- Categories Card -->
        <!-- Update the Categories Card display -->
        <div class="bg-white rounded-lg shadow-md p-6 transform hover:scale-[1.02] transition-all duration-300">
            <div class="flex items-center">
                <div class="p-3 bg-green-100 rounded-full">
                    <i class="fas fa-tags text-green-600 text-2xl"></i>
                </div>
                <div class="ml-4">
                    <h3 class="text-gray-500 text-sm">Top Category</h3>
                    <?php if (!empty($top_categories)): ?>
                        <p class="text-2xl font-bold text-green-600">
                            <?php echo htmlspecialchars($top_categories[0]['name']); ?>
                            <span class="text-sm ml-2">(<?php echo number_format($top_categories[0]['percentage'], 1); ?>%)</span>
                        </p>
                        <p class="text-sm text-gray-500">
                            $<?php echo number_format($top_categories[0]['total_amount'], 2); ?> 
                            <span class="text-xs">(<?php echo $top_categories[0]['expense_count']; ?> expenses)</span>
                        </p>
                    <?php else: ?>
                        <p class="text-2xl font-bold text-green-600">No categories yet</p>
                        <p class="text-sm text-gray-500">$0.00</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Quick Add Card -->
        <div class="bg-white rounded-lg shadow-md p-6 transform hover:scale-[1.02] transition-all duration-300">
            <a href="expenses.php" class="flex items-center group">
                <div class="p-3 bg-blue-100 rounded-full group-hover:bg-blue-200 transition-colors duration-300">
                    <i class="fas fa-plus text-blue-600 text-2xl group-hover:scale-110 transition-transform duration-300"></i>
                </div>
                <div class="ml-4">
                    <h3 class="text-gray-500 text-sm">Quick Add</h3>
                    <p class="text-lg text-blue-600 group-hover:text-blue-700 transition-colors duration-300">New Expense</p>
                    <p class="text-sm text-gray-500">Click to add</p>
                </div>
            </a>
        </div>
    </div>

    <!-- Recent Transactions -->
    <!-- Update the Recent Transactions section to match expenses page styling -->
    <div class="bg-white rounded-lg shadow-lg overflow-hidden">
        <div class="p-6 border-b">
            <h2 class="text-xl font-bold flex items-center">
                <i class="fas fa-history mr-2 text-indigo-600"></i>
                Recent Transactions
            </h2>
        </div>
        <div class="divide-y">
            <?php if (!empty($recent_expenses)): ?>
                <?php foreach ($recent_expenses as $expense): ?>
                    <div class="p-4 hover:bg-gray-50 transition-all duration-300">
                        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                            <div class="flex items-center space-x-4">
                                <div class="p-3 rounded-full" style="background-color: <?php echo htmlspecialchars($expense['category_color']); ?>20">
                                    <i class="fas fa-receipt" style="color: <?php echo htmlspecialchars($expense['category_color']); ?>"></i>
                                </div>
                                <div>
                                    <p class="font-semibold text-lg"><?php echo htmlspecialchars($expense['description']); ?></p>
                                    <p class="text-sm text-gray-500">
                                        <i class="fas fa-tag mr-1" style="color: <?php echo htmlspecialchars($expense['category_color']); ?>"></i>
                                        <?php echo htmlspecialchars($expense['category_name']); ?>
                                    </p>
                                </div>
                            </div>
                            <div class="flex items-center justify-between sm:justify-end w-full sm:w-auto gap-4">
                                <div class="text-right">
                                    <p class="font-bold text-red-600 text-lg">-$<?php echo number_format($expense['amount'], 2); ?></p>
                                    <p class="text-sm text-gray-500">
                                        <i class="far fa-calendar-alt mr-1"></i>
                                        <?php echo date('M d, Y', strtotime($expense['expense_date'])); ?>
                                    </p>
                                </div>
                                <div class="flex space-x-2">
                                    <a href="expenses.php" class="text-indigo-600 hover:text-indigo-800">
                                        <i class="fas fa-external-link-alt"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="p-6 text-center text-gray-500">
                    <i class="fas fa-receipt text-6xl mb-4 animate__animated animate__pulse infinite"></i>
                    <p class="text-xl">No transactions yet</p>
                    <p class="text-sm">Start adding your expenses to track them</p>
                </div>
            <?php endif; ?>
        </div>
        <div class="p-4 bg-gray-50 text-center">
            <a href="expenses.php" 
               class="inline-flex items-center text-indigo-600 hover:text-indigo-800 font-semibold transition-colors duration-300">
                <span>View All Transactions</span>
                <i class="fas fa-arrow-right ml-2"></i>
            </a>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
