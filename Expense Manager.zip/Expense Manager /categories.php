<?php
session_start();
require_once 'config/database.php';

if(!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$page_title = "Manage Categories";
$current_page = "categories";

// Handle category operations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Add category
    if (isset($_POST['add_category'])) {
        $name = trim($_POST['category_name']);
        $color = trim($_POST['category_color']);
        $description = isset($_POST['category_description']) ? trim($_POST['category_description']) : '';

        try {
            $stmt = $pdo->prepare("INSERT INTO categories (name, color, description, user_id) VALUES (?, ?, ?, ?)");
            $stmt->execute([$name, $color, $description, $_SESSION['user_id']]);
            $_SESSION['success'] = "<i class='fas fa-check-circle text-green-500 mr-2'></i>Category has been successfully added.";
        } catch(PDOException $e) {
            $_SESSION['error'] = "<i class='fas fa-exclamation-circle mr-2'></i>Error adding category: " . $e->getMessage();
        }
        header("Location: categories.php");
        exit();
    }

    // Edit category
    if (isset($_POST['edit_category'])) {
        $category_id = $_POST['category_id'];
        $name = trim($_POST['category_name']);
        $color = trim($_POST['category_color']);
        $description = isset($_POST['category_description']) ? trim($_POST['category_description']) : '';

        try {
            $stmt = $pdo->prepare("UPDATE categories SET name = ?, color = ?, description = ? WHERE id = ? AND user_id = ?");
            $stmt->execute([$name, $color, $description, $category_id, $_SESSION['user_id']]);
            $_SESSION['success'] = "<i class='fas fa-check-circle text-green-500 mr-2'></i>Category has been successfully updated.";
        } catch(PDOException $e) {
            $_SESSION['error'] = "<i class='fas fa-exclamation-circle mr-2'></i>Error updating category: " . $e->getMessage();
        }
        header("Location: categories.php");
        exit();
    }

    // Delete category
    if (isset($_POST['delete_category'])) {
        $category_id = $_POST['category_id'];
        try {
            // First, update any expenses that use this category to set category_id to NULL
            $stmt = $pdo->prepare("UPDATE expenses SET category_id = NULL WHERE category_id = ? AND user_id = ?");
            $stmt->execute([$category_id, $_SESSION['user_id']]);
            
            // Then delete the category
            $stmt = $pdo->prepare("DELETE FROM categories WHERE id = ? AND user_id = ?");
            $stmt->execute([$category_id, $_SESSION['user_id']]);
            $_SESSION['success'] = "<i class='fas fa-check-circle text-green-500 mr-2'></i>Category has been successfully deleted.";
        } catch(PDOException $e) {
            $_SESSION['error'] = "<i class='fas fa-exclamation-circle mr-2'></i>Error deleting category: " . $e->getMessage();
        }
        header("Location: categories.php");
        exit();
    }
}

// Pagination parameters
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 9;
$offset = ($page - 1) * $limit;

// Modify the SQL query section
$search_term = isset($_GET['search']) ? trim($_GET['search']) : '';

// Base query without LIMIT for total count
$countSql = "SELECT COUNT(*) FROM categories WHERE user_id = ?";
$searchParams = [$_SESSION['user_id']];

// Modified query to include search conditions
$sql = "SELECT c.*, 
        COALESCE(SUM(e.amount), 0) as total_amount,
        COUNT(e.id) as expense_count
        FROM categories c
        LEFT JOIN expenses e ON c.id = e.category_id
        WHERE c.user_id = ?";

// Add search conditions if search term exists
if ($search_term) {
    $countSql .= " AND (
        name LIKE ? OR 
        description LIKE ? OR 
        EXISTS (
            SELECT 1 FROM expenses e 
            WHERE e.category_id = categories.id 
            AND (
                e.amount LIKE ? OR
                (SELECT COUNT(*) FROM expenses WHERE category_id = categories.id) LIKE ? OR
                (SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE category_id = categories.id) LIKE ?
            )
        )
    )";
    
    $sql .= " AND (
        c.name LIKE ? OR 
        c.description LIKE ? OR 
        e.amount LIKE ? OR
        (SELECT COUNT(*) FROM expenses WHERE category_id = c.id) LIKE ? OR
        (SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE category_id = c.id) LIKE ?
    )";
    
    $searchTerm = "%{$search_term}%";
    $searchParams = array_merge($searchParams, [
        $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm
    ]);
}

$sql .= " GROUP BY c.id ORDER BY c.name ASC LIMIT ?, ?";

// Get total filtered count
$stmt = $pdo->prepare($countSql);
$stmt->execute($searchParams);
$total_categories = $stmt->fetchColumn();
$total_pages = ceil($total_categories / $limit);

// Execute main query with pagination
$stmt = $pdo->prepare($sql);
$finalParams = array_merge($searchParams, [$offset, $limit]);
foreach($finalParams as $i => $param) {
    $stmt->bindValue($i + 1, $param, is_int($param) ? PDO::PARAM_INT : PDO::PARAM_STR);
}
$stmt->execute();
$categories = $stmt->fetchAll();

require_once 'includes/header.php';
?>

<!-- Add Category Button -->
<div class="p-6">
    <div class="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
        <!-- Add Category Button -->
        <button onclick="openCategoryModal()" 
                class="bg-indigo-600 text-white px-6 py-3 rounded-lg shadow-lg hover:bg-indigo-700 transform hover:scale-105 transition-all duration-300 flex items-center">
            <i class="fas fa-plus-circle mr-2 animate__animated animate__rotateIn"></i>
            Add New Category
        </button>

        <input type="text" 
               id="searchCategory" 
               placeholder="Search categories..." 
               class="w-full sm:w-96 border rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500">
    </div>
</div>

<!-- Categories Grid -->
<div class="p-6">
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php if (!empty($categories)): ?>
            <?php foreach($categories as $category): ?>
                <div class="bg-white rounded-lg shadow-lg overflow-hidden transform hover:scale-[1.02] transition-all duration-300">
                    <div class="p-4 border-b" style="background-color: <?php echo htmlspecialchars($category['color']); ?>20">
                        <div class="flex justify-between items-center">
                            <h3 class="text-xl font-bold flex items-center">
                                <i class="fas fa-tag mr-2" style="color: <?php echo htmlspecialchars($category['color']); ?>"></i>
                                <?php echo htmlspecialchars($category['name']); ?>
                            </h3>
                            <div class="flex space-x-2">
                                <button onclick='editCategory(<?php echo json_encode($category); ?>)'
                                        class="text-blue-600 hover:text-blue-800 transition-colors duration-300">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <!-- Replace the existing delete form with this button -->
                                <button type="button" 
                                        class="delete-category-btn text-red-600 hover:text-red-800 transition-colors duration-300"
                                        data-category-id="<?php echo $category['id']; ?>"
                                        data-category-name="<?php echo htmlspecialchars($category['name']); ?>">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </div>
                        </div>
                        <p class="text-gray-600 mt-2"><?php echo htmlspecialchars($category['description']); ?></p>
                    </div>
                    <div class="p-4">
                        <div class="flex justify-between items-center mb-2">
                            <span class="text-gray-600">Total Expenses</span>
                            <span class="font-bold text-indigo-600">$<?php echo number_format($category['total_amount'], 2); ?></span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-gray-600">Number of Expenses</span>
                            <span class="bg-indigo-100 text-indigo-600 px-2 py-1 rounded-full text-sm">
                                <?php echo $category['expense_count']; ?>
                            </span>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-span-full text-center p-8 bg-white rounded-lg shadow">
                <i class="fas fa-tags text-6xl text-gray-300 mb-4 animate__animated animate__pulse infinite"></i>
                <h3 class="text-xl font-bold text-gray-600">No Categories Found</h3>
                <p class="text-gray-500 mt-2">Start by adding your first category</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Pagination -->
    <!-- Update pagination links -->
    <div class="mt-6 flex justify-center items-center space-x-2">
        <?php if ($page > 1): ?>
            <a href="?page=1<?php echo $search_term ? '&search=' . urlencode($search_term) : ''; ?>" 
               class="px-4 py-2 bg-white border border-gray-300 rounded-lg text-indigo-600 hover:bg-indigo-50">
                <i class="fas fa-angle-double-left"></i>
            </a>
            <a href="?page=<?php echo ($page - 1) . ($search_term ? '&search=' . urlencode($search_term) : ''); ?>" 
               class="px-4 py-2 bg-white border border-gray-300 rounded-lg text-indigo-600 hover:bg-indigo-50">
                <i class="fas fa-angle-left"></i>
            </a>
        <?php endif; ?>

        <span class="px-4 py-2 bg-indigo-600 text-white rounded-lg">
            Page <?php echo $page; ?> of <?php echo $total_pages; ?>
        </span>

        <?php if ($page < $total_pages): ?>
            <a href="?page=<?php echo ($page + 1) . ($search_term ? '&search=' . urlencode($search_term) : ''); ?>" 
               class="px-4 py-2 bg-white border border-gray-300 rounded-lg text-indigo-600 hover:bg-indigo-50">
                <i class="fas fa-angle-right"></i>
            </a>
            <a href="?page=<?php echo $total_pages . ($search_term ? '&search=' . urlencode($search_term) : ''); ?>" 
               class="px-4 py-2 bg-white border border-gray-300 rounded-lg text-indigo-600 hover:bg-indigo-50">
                <i class="fas fa-angle-double-right"></i>
            </a>
        <?php endif; ?>
    </div>
</div>

<!-- Category Modal -->
<div id="categoryModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
    <div class="flex items-center justify-center min-h-screen p-4">
        <div class="bg-white rounded-lg shadow-xl w-full max-w-md transform transition-all duration-300 scale-95 opacity-0" id="modalContent">
            <div class="p-6">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-xl font-bold" id="modalTitle">Add New Category</h3>
                    <button onclick="closeCategoryModal()" class="text-gray-400 hover:text-gray-600">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <form method="POST" class="space-y-4">
                    <input type="hidden" id="category_id" name="category_id">
                    
                    <div>
                        <label for="category_name" class="block text-sm font-medium text-gray-700 mb-1">Category Name</label>
                        <input type="text" id="category_name" name="category_name" required
                               class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                    </div>
                    
                    <div>
                        <label for="category_description" class="block text-sm font-medium text-gray-700 mb-1">Description (Optional)</label>
                        <textarea id="category_description" name="category_description" rows="3"
                                  class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500"></textarea>
                    </div>
                    
                    <div>
                        <label for="category_color" class="block text-sm font-medium text-gray-700 mb-1">Color</label>
                        <input type="color" id="category_color" name="category_color" value="#4F46E5"
                               class="w-full h-10 px-1 py-1 border rounded-lg">
                    </div>
                    
                    <div class="flex justify-end space-x-3 mt-6">
                        <button type="button" onclick="closeCategoryModal()"
                                class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors duration-200">
                            Cancel
                        </button>
                        <button type="submit" id="submitBtn" name="add_category"
                                class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors duration-200">
                            Save Category
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Add this delete confirmation modal after the category modal -->
<div id="deleteModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
    <div class="flex items-center justify-center min-h-screen p-4">
        <div class="bg-white rounded-lg shadow-xl w-full max-w-md transform transition-all duration-300 scale-95 opacity-0" id="deleteModalContent">
            <div class="p-6">
                <div class="flex items-center mb-4">
                    <div class="rounded-full bg-red-100 p-3 mr-4">
                        <i class="fas fa-exclamation-triangle text-red-600 text-xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-900">Delete Category</h3>
                </div>
                <p class="text-gray-600 mb-4">Are you sure you want to delete this category? Associated expenses will remain but will no longer be linked to this category.</p>
                <form id="deleteCategoryForm" method="POST" class="flex justify-end space-x-3">
                    <input type="hidden" name="category_id" id="delete_category_id">
                    <button type="button" onclick="closeDeleteModal()" 
                            class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors duration-200">
                        Cancel
                    </button>
                    <button type="submit" name="delete_category"
                            class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors duration-200">
                        Delete Category
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Update the script section -->
<script>
let currentModal = null;

function openCategoryModal(isEdit = false) {
    if (!isEdit) {
        resetForm();
    }
    currentModal = 'category';
    document.getElementById('categoryModal').classList.remove('hidden');
    setTimeout(() => {
        document.getElementById('modalContent').classList.remove('scale-95', 'opacity-0');
        document.getElementById('modalContent').classList.add('scale-100', 'opacity-100');
    }, 10);
}

function closeCategoryModal() {
    document.getElementById('modalContent').classList.add('scale-95', 'opacity-0');
    document.getElementById('modalContent').classList.remove('scale-100', 'opacity-100');
    setTimeout(() => {
        document.getElementById('categoryModal').classList.add('hidden');
        if (currentModal !== 'edit') {
            resetForm();
        }
    }, 300);
}

function editCategory(category) {
    currentModal = 'edit';
    document.getElementById('modalTitle').textContent = 'Edit Category';
    document.getElementById('category_id').value = category.id;
    document.getElementById('category_name').value = category.name;
    document.getElementById('category_color').value = category.color;
    document.getElementById('submitBtn').name = 'edit_category';
    document.getElementById('submitBtn').textContent = 'Update Category';
    openCategoryModal(true);
}

function resetForm() {
    document.getElementById('modalTitle').textContent = 'Add New Category';
    document.getElementById('category_id').value = '';
    document.getElementById('category_name').value = '';
    document.getElementById('category_color').value = '#4F46E5';
    document.getElementById('submitBtn').name = 'add_category';
    document.getElementById('submitBtn').textContent = 'Save Category';
}

function openDeleteModal(categoryId, categoryName) {
    currentModal = 'delete';
    document.getElementById('delete_category_id').value = categoryId;
    document.getElementById('deleteModal').classList.remove('hidden');
    setTimeout(() => {
        document.getElementById('deleteModalContent').classList.remove('scale-95', 'opacity-0');
        document.getElementById('deleteModalContent').classList.add('scale-100', 'opacity-100');
    }, 10);
}

function closeDeleteModal() {
    document.getElementById('deleteModalContent').classList.add('scale-95', 'opacity-0');
    document.getElementById('deleteModalContent').classList.remove('scale-100', 'opacity-100');
    setTimeout(() => {
        document.getElementById('deleteModal').classList.add('hidden');
    }, 300);
}

// Update the delete button onclick handler in the categories grid
document.querySelectorAll('.delete-category-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
        e.preventDefault();
        const categoryId = btn.dataset.categoryId;
        const categoryName = btn.dataset.categoryName;
        openDeleteModal(categoryId, categoryName);
    });
});

// Close modals when clicking outside
window.onclick = function(event) {
    if (event.target.id === 'categoryModal' || event.target.id === 'deleteModal') {
        if (event.target.id === 'categoryModal') {
            closeCategoryModal();
        } else {
            closeDeleteModal();
        }
    }
}

// Close modals on escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        if (currentModal === 'category' || currentModal === 'edit') {
            closeCategoryModal();
        } else if (currentModal === 'delete') {
            closeDeleteModal();
        }
    }
});

// Update the search functionality
document.getElementById('searchCategory').addEventListener('input', function(e) {
    const searchTerm = e.target.value;
    const currentUrl = new URL(window.location.href);
    
    if (searchTerm) {
        currentUrl.searchParams.set('search', searchTerm);
    } else {
        currentUrl.searchParams.delete('search');
    }
    
    // Reset to first page when searching
    currentUrl.searchParams.delete('page');
    
    // Use history.pushState to update URL without reload
    history.pushState({}, '', currentUrl);
    
    // Fetch and update results
    fetch(currentUrl)
        .then(response => response.text())
        .then(html => {
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');
            document.querySelector('.grid').innerHTML = doc.querySelector('.grid').innerHTML;
            document.querySelector('.mt-6').innerHTML = doc.querySelector('.mt-6').innerHTML;
        });
});

// Remove the old filterCategories function as it's no longer needed
function filterCategories(searchTerm) {
    const categories = document.querySelectorAll('.grid > div');
    let hasVisibleCategories = false;

    categories.forEach(category => {
        const name = category.querySelector('h3')?.textContent.toLowerCase() || '';
        const description = category.querySelector('p.text-gray-600')?.textContent.toLowerCase() || '';
        const totalExpenses = category.querySelector('.text-indigo-600')?.textContent.toLowerCase() || '';
        const expenseCount = category.querySelector('.bg-indigo-100')?.textContent.toLowerCase() || '';
        
        const matchesSearch = !searchTerm || 
            name.includes(searchTerm) || 
            description.includes(searchTerm) || 
            totalExpenses.includes(searchTerm) ||
            expenseCount.includes(searchTerm);

        if (matchesSearch) {
            category.style.display = '';
            hasVisibleCategories = true;
        } else {
            category.style.display = 'none';
        }
    });

    // Show/hide no results message
    const noResultsDiv = document.getElementById('noSearchResults');
    if (!hasVisibleExpenses) {
        if (!noResultsDiv) {
            const message = `
                <div id="noSearchResults" class="col-span-full text-center p-8 bg-white rounded-lg shadow">
                    <i class="fas fa-search text-6xl text-gray-300 mb-4"></i>
                    <h3 class="text-xl font-bold text-gray-600">No matching categories found</h3>
                    <p class="text-gray-500 mt-2">Try adjusting your search terms (name, description, total amount, or number of expenses)</p>
                </div>
            `;
            document.querySelector('.grid').insertAdjacentHTML('beforeend', message);
        }
    } else if (noResultsDiv) {
        noResultsDiv.remove();
    }
}

// Only add input event listener to search input
searchInput.addEventListener('input', filterCategories);

// Apply page reload filtering for dropdown filters
function applyFilters() {
    const currentUrl = new URL(window.location.href);
    const expenseFilterValue = expenseFilter.value;
    const amountFilterValue = amountFilter.value;
    
    if (expenseFilterValue) {
        currentUrl.searchParams.set('expense_filter', expenseFilterValue);
    } else {
        currentUrl.searchParams.delete('expense_filter');
    }
    
    if (amountFilterValue) {
        currentUrl.searchParams.set('amount_filter', amountFilterValue);
    } else {
        currentUrl.searchParams.delete('amount_filter');
    }
    
    // Reset to first page when filtering
    currentUrl.searchParams.delete('page');
    
    window.location.href = currentUrl.toString();
}

// Add change event listeners to dropdown filters
expenseFilter.addEventListener('change', applyFilters);
amountFilter.addEventListener('change', applyFilters);

// Modified keyboard shortcut to only focus the search input
document.addEventListener('keydown', (e) => {
    // Only handle forward slash key to focus search
    if (e.key === '/' && !['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName)) {
        e.preventDefault();
        searchInput.focus();
    }
});
</script>

<?php require_once 'includes/footer.php'; ?>
