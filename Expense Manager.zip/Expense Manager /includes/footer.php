</div><!-- End of Main Content Area -->

            <!-- Footer -->
            <footer class="mt-auto p-4 text-gray-600 bg-transparent">
                <div class="container mx-auto text-center space-y-2">
                    <p class="text-sm">&copy; <?php echo date('Y'); ?> Expense Manager. All rights reserved.</p>
                    <p class="text-sm">
                        Crafted by 
                        <a href="mailto:jameskinyungu@gmail.com" 
                           class="text-indigo-600 hover:text-indigo-800 transition-colors duration-300">
                            jameskinyungu@gmail.com
                        </a>
                    </p>
                </div>
            </footer>
        </div><!-- End of flex-1 flex flex-col -->
    </div><!-- End of flex min-h-screen -->

    <?php if(isset($additional_scripts)): ?>
        <?php echo $additional_scripts; ?>
    <?php endif; ?>
</body>
</html>
