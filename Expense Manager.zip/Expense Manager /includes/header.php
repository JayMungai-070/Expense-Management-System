<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="image/icon.png">
    <title><?php echo isset($page_title) ? $page_title . ' - ' : ''; ?>Expense Manager</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <?php if(isset($additional_css)): ?>
        <?php echo $additional_css; ?>
    <?php endif; ?>
    <!-- Update the styles section -->
    <style>
        .sidebar-transition {
            transition: none;
        }
        .fade-in {
            animation: fadeIn 0.5s ease-in;
        }
        .slide-in {
            animation: slideIn 0.3s ease-out;
        }
        .hover-scale {
            transition: transform 0.2s;
        }
        .hover-scale:hover {
            transform: scale(1.05);
        }
        .spinner {
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        @keyframes slideIn {
            from { transform: translateX(-100%); }
            to { transform: translateX(0); }
        }
        .notification {
            animation: slideDown 0.5s ease-out;
        }
        @keyframes slideDown {
            from { transform: translateY(-100%); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        /* Add these new styles */
        @media (max-width: 1024px) {
            .mobile-sidebar {
                width: 250px !important;
                background-color: rgba(79, 70, 229, 0.9) !important;
                backdrop-filter: blur(10px);
                -webkit-backdrop-filter: blur(10px);
            }
        }
        .nav-link {
            position: relative;
            overflow: hidden;
        }
        .nav-link.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            width: 4px;
            background-color: white;
            border-radius: 0 2px 2px 0;
        }
        .nav-link.active {
            background-color: rgba(255, 255, 255, 0.1);
            font-weight: bold;
        }
        /* Update the mobile-sidebar styles */
        .mobile-sidebar {
            background-color: rgba(255, 255, 255, 0.85) !important;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-right: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 0 24px 24px 0;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            width: 300px;
        }
        
        @media (max-width: 1024px) {
            .mobile-sidebar {
                width: 300px !important;
                background-color: rgba(255, 255, 255, 0.85) !important;
                backdrop-filter: blur(10px);
                -webkit-backdrop-filter: blur(10px);
            }
        }
        
        /* Update the sidebar navigation styles */
        .nav-link {
            position: relative;
            overflow: hidden;
            color: #4F46E5;
            transition: all 0.3s ease;
        }
        
        .nav-link:hover {
            background-color: rgba(79, 70, 229, 0.1);
        }
        
        .nav-link.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            width: 4px;
            background-color: #4F46E5;
            border-radius: 0 2px 2px 0;
        }
        
        .nav-link.active {
            background-color: rgba(79, 70, 229, 0.15);
            font-weight: bold;
            color: #4F46E5;
        }
    
        /* Transparent header styles */
        .transparent-header {
            background-color: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
        }
        #logoutModal {
            z-index: 99999;
        }

        #logoutModal .bg-white {
            position: relative;
            z-index: 100000;
        }

        /* Ensure other elements don't overlap */
        .sidebar {
            z-index: 50;
        }

        .header {
            z-index: 40;
        }

        .main-content {
            z-index: 30;
        }

        /* Modal animation styles */
        .modal-enter {
            opacity: 0;
            transform: scale(0.95);
        }

        .modal-enter-active {
            opacity: 1;
            transform: scale(1);
            transition: opacity 200ms ease-out, transform 200ms ease-out;
        }

        .modal-exit {
            opacity: 1;
            transform: scale(1);
        }

        .modal-exit-active {
            opacity: 0;
            transform: scale(0.95);
            transition: opacity 200ms ease-in, transform 200ms ease-in;
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- Logout Modal - Styled to match delete category prompt -->
    <div id="logoutModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
        <div class="flex items-center justify-center min-h-screen p-4">
            <div class="bg-white rounded-lg shadow-xl w-full max-w-md transform transition-all duration-300 scale-95 opacity-0" id="logoutModalContent">
                <div class="p-6">
                    <div class="flex items-center mb-4">
                        <div class="rounded-full bg-red-100 p-3 mr-4">
                            <i class="fas fa-exclamation-triangle text-red-600 text-xl"></i>
                        </div>
                        <h3 class="text-xl font-bold text-gray-900">Confirm Logout</h3>
                    </div>
                    <p class="text-gray-600 mb-4">Are you sure you want to logout from your account?</p>
                    <div class="flex justify-end space-x-3">
                        <button type="button" onclick="closeLogoutModal()" 
                                class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors duration-200">
                            Cancel
                        </button>
                        <a href="logout.php"
                           class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors duration-200">
                            Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    function openLogoutModal() {
        document.getElementById('logoutModal').classList.remove('hidden');
        setTimeout(() => {
            document.getElementById('logoutModalContent').classList.remove('scale-95', 'opacity-0');
            document.getElementById('logoutModalContent').classList.add('scale-100', 'opacity-100');
        }, 10);
    }

    function closeLogoutModal() {
        document.getElementById('logoutModalContent').classList.add('scale-95', 'opacity-0');
        document.getElementById('logoutModalContent').classList.remove('scale-100', 'opacity-100');
        setTimeout(() => {
            document.getElementById('logoutModal').classList.add('hidden');
        }, 300);
    }

    // Close modal when clicking outside
    document.getElementById('logoutModal').addEventListener('click', function(event) {
        if (event.target === this) {
            closeLogoutModal();
        }
    });

    // Close modal on escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && !document.getElementById('logoutModal').classList.contains('hidden')) {
            closeLogoutModal();
        }
    });
    </script>

    <!-- Loading Spinner - Adjust z-index to be lower than logout modal -->
    <div id="loader" class="fixed inset-0 bg-gray-900 bg-opacity-50 z-[9999] flex items-center justify-center hidden">
        <div class="bg-white p-5 rounded-full">
            <i class="fas fa-circle-notch fa-spin text-indigo-600 text-4xl"></i>
        </div>
    </div>

    <!-- Success/Error Messages -->
    <div id="notifications-container" class="fixed top-4 right-4 z-50 space-y-4 min-w-[300px]">
        <?php if(isset($_SESSION['success'])): ?>
            <div class="notification-toast bg-white border-l-4 border-green-500 rounded-lg shadow-lg p-4 mb-4 animate__animated animate__fadeInRight">
                <div class="flex items-center">
                    <div class="ml-3 flex-1">
                        <?php echo $_SESSION['success']; ?>
                    </div>
                    <button onclick="this.closest('.notification-toast').remove()" class="ml-4">
                        <i class="fas fa-times text-gray-400 hover:text-gray-500"></i>
                    </button>
                </div>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>

        <?php if(isset($_SESSION['error'])): ?>
            <div class="notification-toast bg-white border-l-4 border-red-500 rounded-lg shadow-lg p-4 mb-4 animate__animated animate__fadeInRight">
                <div class="flex items-center">
                    <div class="ml-3 flex-1">
                        <?php echo $_SESSION['error']; ?>
                    </div>
                    <button onclick="this.closest('.notification-toast').remove()" class="ml-4">
                        <i class="fas fa-times text-gray-400 hover:text-gray-500"></i>
                    </button>
                </div>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>
    </div>

    <script>
    // Auto-dismiss notifications after 5 seconds
    document.addEventListener('DOMContentLoaded', function() {
        const notifications = document.querySelectorAll('.notification-toast');
        notifications.forEach(notification => {
            setTimeout(() => {
                notification.classList.add('animate__fadeOutRight');
                setTimeout(() => {
                    notification.remove();
                }, 500);
            }, 5000);
        });
    });
    </script>

    <div class="flex min-h-screen">
        <!-- Mobile Sidebar Overlay -->
        <div id="sidebar-overlay" class="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm z-40 lg:hidden hidden" onclick="closeSidebar()"></div>

        <!-- Sidebar -->
        <aside class="mobile-sidebar min-h-screen fixed lg:static left-0 top-0 transform -translate-x-full lg:transform-none transition-all duration-300 z-50 sidebar-transition" id="sidebar">
            <div class="p-4">
                <div class="flex items-center justify-between mb-8">
                    <a href="dashboard.php" class="text-2xl font-bold hover-scale flex items-center text-indigo-600">
                        <img src="image/logo.png" alt="Logo" class="h-8 w-auto mr-2">
                        <span class="animate__animated animate__fadeIn">Expense Manager</span>
                    </a>
                    <button class="lg:hidden hover:rotate-90 transition-transform duration-300 text-indigo-600" id="close-sidebar">
                        <i class="fas fa-times text-xl"></i>
                    </button>
                </div>

                <nav class="space-y-2">
                    <a href="dashboard.php" class="nav-link block py-2.5 px-4 rounded transition duration-300 transform hover:scale-105 <?php echo $current_page === 'dashboard' ? 'active' : ''; ?>">
                        <i class="fas fa-home mr-2"></i>Dashboard
                    </a>
                    <a href="expenses.php" class="nav-link block py-2.5 px-4 rounded transition duration-300 transform hover:scale-105 <?php echo $current_page === 'expenses' ? 'active' : ''; ?>">
                        <i class="fas fa-money-bill-wave mr-2"></i>Expenses
                    </a>
                    <a href="categories.php" class="nav-link block py-2.5 px-4 rounded transition duration-300 transform hover:scale-105 <?php echo $current_page === 'categories' ? 'active' : ''; ?>">
                        <i class="fas fa-tags mr-2"></i>Categories
                    </a>
                    <a href="reports.php" class="nav-link block py-2.5 px-4 rounded transition duration-300 transform hover:scale-105 <?php echo $current_page === 'reports' ? 'active' : ''; ?>">
                        <i class="fas fa-chart-bar mr-2"></i>Reports
                    </a>
                </nav>
            </div>
        </aside>

        <!-- Main Content -->
        <div class="flex-1 flex flex-col">
            <!-- Top Navigation -->
            <!-- Update the header styles in the style section -->
            <style>
                /* Update header styles */
                .transparent-header {
                    background-color: transparent !important;
                    border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                }
            
                .profile-dropdown {
                    background-color: rgba(255, 255, 255, 0.9);
                    backdrop-filter: blur(10px);
                    -webkit-backdrop-filter: blur(10px);
                    border: 1px solid rgba(255, 255, 255, 0.2);
                }
            </style>
            
            <!-- Update the header navigation section -->
            <nav class="transparent-header p-4 sticky top-0 z-40">
                <div class="flex justify-between items-center">
                    <div class="flex items-center space-x-4">
                        <button class="lg:hidden text-indigo-600 hover:bg-indigo-100 p-2 rounded-lg transition-all duration-300" id="open-sidebar">
                            <i class="fas fa-bars text-xl"></i>
                        </button>
                        <div class="flex items-center space-x-2">
                            <i class="fas fa-chart-pie text-indigo-600 text-2xl"></i>
                            <h1 class="text-xl font-bold text-indigo-600"><?php echo $page_title; ?></h1>
                        </div>
                    </div>
                    <!-- Update the profile section in the header -->
                    <div class="flex items-center space-x-4">
                        <div class="relative group">
                            <div class="flex items-center space-x-3 p-2">
                                <span class="hidden md:block text-gray-700"><?php echo $_SESSION['fullname']; ?></span>
                                <img src="uploads/profile/<?php echo $_SESSION['profile_picture'] ?: 'default.png'; ?>" 
                                     alt="Profile" 
                                     id="headerProfilePic"
                                     class="w-10 h-10 rounded-full border-2 border-indigo-600 object-cover">
                                <button id="profileDropdownBtn" class="focus:outline-none">
                                    <i class="fas fa-chevron-down text-gray-600 text-sm transition-transform duration-300"></i>
                                </button>
                            </div>
                            <div id="profileDropdown" class="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg hidden animate__animated animate__fadeIn">
                                <div class="p-3 border-b border-gray-100">
                                    <p class="text-sm font-semibold text-gray-800"><?php echo $_SESSION['fullname']; ?></p>
                                    <?php if(isset($_SESSION['email'])): ?>
                                        <p class="text-xs text-gray-500"><?php echo $_SESSION['email']; ?></p>
                                    <?php endif; ?>
                                </div>
                                <a href="profile.php" class="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 transition duration-200">
                                    <i class="fas fa-user-circle mr-2 text-indigo-500"></i>Profile Settings
                                </a>
                                <hr class="border-gray-100">
                                <button onclick="confirmLogout()" class="w-full text-left flex items-center px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition duration-200">
                                    <i class="fas fa-sign-out-alt mr-2"></i>Logout
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>

            <!-- Add this near the top of the body, after the loader div -->
            <!-- Logout Confirmation Modal -->
            <!-- First, remove the old logout confirmation script at the bottom -->
            
            <!-- Update the logout modal to be more responsive -->
            <div id="logoutModal" class="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm z-[9999] hidden">
                <div class="min-h-screen px-4 flex items-center justify-center">
                    <div class="bg-white rounded-2xl shadow-xl w-full max-w-md transform transition-all duration-300 scale-95 opacity-0">
                        <div class="p-6">
                            <div class="flex items-center justify-between mb-4">
                                <h3 class="text-xl font-bold text-gray-800">Confirm Logout</h3>
                                <button onclick="closeLogoutModal()" class="text-gray-400 hover:text-gray-600 transition-colors p-2 hover:bg-gray-100 rounded-full">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                            <div class="mb-6">
                                <div class="flex items-center justify-center text-red-500 mb-4">
                                    <i class="fas fa-sign-out-alt text-4xl"></i>
                                </div>
                                <p class="text-gray-600 text-center">Are you sure you want to logout from your account?</p>
                            </div>
                            <div class="flex justify-end space-x-3">
                                <button onclick="closeLogoutModal()" 
                                        class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors duration-200 flex items-center">
                                    <i class="fas fa-times mr-2"></i>
                                    Cancel
                                </button>
                                <a href="logout.php" 
                                   class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors duration-200 flex items-center">
                                    <i class="fas fa-sign-out-alt mr-2"></i>
                                    Logout
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Update the logout confirmation script -->
            <script>
            function confirmLogout() {
                const modal = document.getElementById('logoutModal');
                const modalContent = modal.querySelector('.max-w-md');
                
                // Show modal
                modal.style.display = 'block';
                modal.classList.remove('hidden');
                
                // Animate in
                setTimeout(() => {
                    modalContent.classList.remove('scale-95', 'opacity-0');
                    modalContent.classList.add('scale-100', 'opacity-100');
                }, 10);
            }

            function closeLogoutModal() {
                const modal = document.getElementById('logoutModal');
                const modalContent = modal.querySelector('.max-w-md');
                
                // Animate out
                modalContent.classList.remove('scale-100', 'opacity-100');
                modalContent.classList.add('scale-95', 'opacity-0');
                
                // Hide modal
                setTimeout(() => {
                    modal.classList.add('hidden');
                    modal.style.display = 'none';
                }, 200);
            }

            // Event Listeners
            document.addEventListener('DOMContentLoaded', function() {
                const modal = document.getElementById('logoutModal');
                
                // Close on outside click
                modal.addEventListener('click', function(e) {
                    if (e.target === modal) {
                        closeLogoutModal();
                    }
                });

                // Close on ESC key
                document.addEventListener('keydown', function(e) {
                    if (e.key === 'Escape' && !modal.classList.contains('hidden')) {
                        closeLogoutModal();
                    }
                });
            });
            </script>
            <!-- Main Content Area -->
            <div class="flex-1 p-6">

<script>
    // Sidebar Toggle Functions
    function openSidebar() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebar-overlay');
        
        if (sidebar && overlay) {
            sidebar.classList.remove('-translate-x-full');
            overlay.classList.remove('hidden');
            document.body.style.overflow = 'hidden';
        }
    }

    function closeSidebar() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebar-overlay');
        
        if (sidebar && overlay) {
            sidebar.classList.add('-translate-x-full');
            overlay.classList.add('hidden');
            document.body.style.overflow = 'auto';
        }
    }

    // Wait for DOM to be fully loaded
    document.addEventListener('DOMContentLoaded', function() {
        const openButton = document.getElementById('open-sidebar');
        const closeButton = document.getElementById('close-sidebar');
        
        if (openButton) {
            openButton.addEventListener('click', openSidebar);
        }
        
        if (closeButton) {
            closeButton.addEventListener('click', closeSidebar);
        }

        // Close sidebar when clicking outside on mobile
        const overlay = document.getElementById('sidebar-overlay');
        if (overlay) {
            overlay.addEventListener('click', closeSidebar);
        }

        // Close sidebar when screen size becomes large
        window.addEventListener('resize', function() {
            if (window.innerWidth >= 1024) {
                closeSidebar();
            }
        });
    });
</script>
<script>
    // Logout Modal Functions
    function confirmLogout() {
        const modal = document.getElementById('logoutModal');
        const modalContent = modal.querySelector('.max-w-md');
        
        modal.classList.remove('hidden');
        setTimeout(() => {
            modalContent.classList.remove('scale-95', 'opacity-0');
            modalContent.classList.add('scale-100', 'opacity-100');
        }, 50);
    }

    function closeLogoutModal() {
        const modal = document.getElementById('logoutModal');
        const modalContent = modal.querySelector('.max-w-md');
        
        modalContent.classList.remove('scale-100', 'opacity-100');
        modalContent.classList.add('scale-95', 'opacity-0');
        
        setTimeout(() => {
            modal.classList.add('hidden');
        }, 200);
    }

    // Close modal when clicking outside
    document.getElementById('logoutModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeLogoutModal();
        }
    });

    // Close modal on escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && !document.getElementById('logoutModal').classList.contains('hidden')) {
            closeLogoutModal();
        }
    });

    // Profile Dropdown Toggle
    document.addEventListener('DOMContentLoaded', function() {
        const profileDropdownBtn = document.getElementById('profileDropdownBtn');
        const profileDropdown = document.getElementById('profileDropdown');
        let isDropdownOpen = false;

        if (profileDropdownBtn && profileDropdown) {
            profileDropdownBtn.addEventListener('click', () => {
                isDropdownOpen = !isDropdownOpen;
                if (isDropdownOpen) {
                    profileDropdown.classList.remove('hidden');
                    profileDropdownBtn.querySelector('i').style.transform = 'rotate(180deg)';
                } else {
                    profileDropdown.classList.add('hidden');
                    profileDropdownBtn.querySelector('i').style.transform = 'rotate(0)';
                }
            });

            // Close dropdown when clicking outside
            document.addEventListener('click', (event) => {
                const isClickInside = profileDropdownBtn.contains(event.target) || 
                                    profileDropdown.contains(event.target);
                
                if (!isClickInside && !profileDropdown.classList.contains('hidden')) {
                    isDropdownOpen = false;
                    profileDropdown.classList.add('hidden');
                    profileDropdownBtn.querySelector('i').style.transform = 'rotate(0)';
                }
            });
        }
    });
</script>
