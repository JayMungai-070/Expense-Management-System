<?php
session_start();
$username = $_SESSION['fullname']; // Store the name before destroying session
session_destroy();
session_start(); // Start new session for the success message
$_SESSION['success'] = "<i class='fas fa-check-circle text-green-500 mr-2'></i>Goodbye, $username! You have been logged out successfully.";
header("Location: login.php");
exit();
