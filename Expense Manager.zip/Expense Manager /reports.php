<?php
session_start();
require_once 'config/database.php';

if(!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = "Please login to access reports.";
    header("Location: login.php");
    exit();
}

// Fetch user details
$user_query = $pdo->prepare("SELECT fullname, email, created_at FROM users WHERE id = ?");
$user_query->execute([$_SESSION['user_id']]);
$user_details = $user_query->fetch(PDO::FETCH_ASSOC);

// Format the user's account creation date
$account_created = new DateTime($user_details['created_at']);
$account_age = $account_created->diff(new DateTime())->days;

// Generate Report
if(isset($_POST['generate_report'])) {
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $category_id = $_POST['category_id'] ?? null;

    try {
        if($category_id) {
            $stmt = $pdo->prepare("SELECT * FROM expenses WHERE user_id = ? AND category_id = ? AND expense_date BETWEEN ? AND ?");
            $stmt->execute([$_SESSION['user_id'], $category_id, $start_date, $end_date]);
        } else {
            $stmt = $pdo->prepare("SELECT * FROM expenses WHERE user_id = ? AND expense_date BETWEEN ? AND ?");
            $stmt->execute([$_SESSION['user_id'], $start_date, $end_date]);
        }
        
        $expenses = $stmt->fetchAll();
        if(count($expenses) > 0) {
            $_SESSION['success'] = "Report generated successfully! Found " . count($expenses) . " expenses. <i class='fas fa-chart-bar animate__animated animate__bounceIn'></i>";
        } else {
            $_SESSION['info'] = "No expenses found for the selected period. <i class='fas fa-info-circle'></i>";
        }
    } catch(PDOException $e) {
        $_SESSION['error'] = "Error generating report: " . $e->getMessage();
    }
    header("Location: reports.php");
    exit();
}

// Export Report
if(isset($_POST['export_report'])) {
    try {
        // Your export logic here
        $_SESSION['success'] = "Report exported successfully! Check your downloads folder. <i class='fas fa-file-export animate__animated animate__bounceIn'></i>";
    } catch(Exception $e) {
        $_SESSION['error'] = "Error exporting report: " . $e->getMessage();
    }
    header("Location: reports.php");
    exit();
}

$page_title = "Expense Reports";
$current_page = "reports";

// Get date range from query parameters or set defaults
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-t');

// Fetch total expenses for the period
$stmt = $pdo->prepare("
    SELECT 
        SUM(amount) as total,
        AVG(amount) as average,
        MAX(amount) as highest,
        MIN(amount) as lowest,
        COUNT(*) as count
    FROM expenses 
    WHERE user_id = ? AND expense_date BETWEEN ? AND ?
");
$stmt->execute([$_SESSION['user_id'], $start_date, $end_date]);
$expense_stats = $stmt->fetch();

// Fetch expenses by category
$stmt = $pdo->prepare("
    SELECT 
        c.name, 
        COALESCE(c.color, '#4F46E5') as color, 
        SUM(e.amount) as total
    FROM expenses e
    JOIN categories c ON e.category_id = c.id
    WHERE e.user_id = ? AND e.expense_date BETWEEN ? AND ?
    GROUP BY c.id, c.name, c.color
    ORDER BY total DESC
");
$stmt->execute([$_SESSION['user_id'], $start_date, $end_date]);
$expenses_by_category = $stmt->fetchAll();

// Fetch daily expenses for line chart
$stmt = $pdo->prepare("
    SELECT DATE(expense_date) as date, SUM(amount) as total
    FROM expenses
    WHERE user_id = ? AND expense_date BETWEEN ? AND ?
    GROUP BY DATE(expense_date)
    ORDER BY date
");
$stmt->execute([$_SESSION['user_id'], $start_date, $end_date]);
$daily_expenses = $stmt->fetchAll();

// Fetch expense patterns
$stmt = $pdo->prepare("
    SELECT 
        DAYNAME(expense_date) as day_of_week,
        COUNT(*) as transaction_count,
        AVG(amount) as avg_amount,
        SUM(amount) as total_amount
    FROM expenses 
    WHERE user_id = ? AND expense_date BETWEEN ? AND ?
    GROUP BY DAYNAME(expense_date)
    ORDER BY FIELD(DAYNAME(expense_date), 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')
");
$stmt->execute([$_SESSION['user_id'], $start_date, $end_date]);
$spending_patterns = $stmt->fetchAll();

// Fetch expense size distribution
$stmt = $pdo->prepare("
    SELECT 
        CASE
            WHEN amount < 10 THEN 'Less than $10'
            WHEN amount BETWEEN 10 AND 50 THEN '$10 - $50'
            WHEN amount BETWEEN 50 AND 100 THEN '$50 - $100'
            WHEN amount BETWEEN 100 AND 500 THEN '$100 - $500'
            ELSE 'Over $500'
        END as range_label,
        COUNT(*) as count,
        SUM(amount) as total,
        AVG(amount) as average
    FROM expenses 
    WHERE user_id = ? AND expense_date BETWEEN ? AND ?
    GROUP BY range_label
    ORDER BY MIN(amount)
");
$stmt->execute([$_SESSION['user_id'], $start_date, $end_date]);
$expense_ranges = $stmt->fetchAll();

// Additional CSS for date picker
$additional_css = '
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
';

// Additional scripts for charts and date picker
$additional_scripts = '
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
';

require_once 'includes/header.php';
?>

<div class="p-6 space-y-6 animate__animated animate__fadeIn">
    <!-- Date Range Selector -->
    <div class="bg-white rounded-lg shadow-lg p-6">
        <form id="dateRangeForm" class="flex flex-wrap gap-4 items-end">
            <div class="flex-1 min-w-[200px]">
                <label class="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
                <input type="date" name="start_date" id="start_date" value="<?php echo $start_date; ?>"
                       class="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500">
            </div>
            <div class="flex-1 min-w-[200px]">
                <label class="block text-sm font-medium text-gray-700 mb-1">End Date</label>
                <input type="date" name="end_date" id="end_date" value="<?php echo $end_date; ?>"
                       class="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500">
            </div>
            <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition-colors duration-300 flex items-center">
                <i class="fas fa-filter mr-2"></i>
                Apply Filter
            </button>
        </form>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <!-- Total Expenses -->
        <div class="bg-white rounded-lg shadow-lg p-6 transform hover:scale-105 transition-all duration-300">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-500 text-sm">Total Expenses</p>
                    <p class="text-2xl font-bold text-indigo-600">$<?php echo number_format($expense_stats['total'] ?? 0, 2); ?></p>
                </div>
                <div class="p-3 bg-indigo-100 rounded-full">
                    <i class="fas fa-money-bill-wave text-indigo-600 text-xl"></i>
                </div>
            </div>
            <p class="text-sm text-gray-500 mt-2">
                <?php echo $expense_stats['count']; ?> transactions
            </p>
        </div>

        <!-- Average Expense -->
        <div class="bg-white rounded-lg shadow-lg p-6 transform hover:scale-105 transition-all duration-300">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-500 text-sm">Average Expense</p>
                    <p class="text-2xl font-bold text-green-600">$<?php echo number_format($expense_stats['average'] ?? 0, 2); ?></p>
                </div>
                <div class="p-3 bg-green-100 rounded-full">
                    <i class="fas fa-chart-line text-green-600 text-xl"></i>
                </div>
            </div>
            <p class="text-sm text-gray-500 mt-2">Per transaction</p>
        </div>

        <!-- Highest Expense -->
        <div class="bg-white rounded-lg shadow-lg p-6 transform hover:scale-105 transition-all duration-300">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-500 text-sm">Highest Expense</p>
                    <p class="text-2xl font-bold text-red-600">$<?php echo number_format($expense_stats['highest'] ?? 0, 2); ?></p>
                </div>
                <div class="p-3 bg-red-100 rounded-full">
                    <i class="fas fa-arrow-up text-red-600 text-xl"></i>
                </div>
            </div>
            <p class="text-sm text-gray-500 mt-2">Single transaction</p>
        </div>

        <!-- Lowest Expense -->
        <div class="bg-white rounded-lg shadow-lg p-6 transform hover:scale-105 transition-all duration-300">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-500 text-sm">Lowest Expense</p>
                    <p class="text-2xl font-bold text-blue-600">$<?php echo number_format($expense_stats['lowest'] ?? 0, 2); ?></p>
                </div>
                <div class="p-3 bg-blue-100 rounded-full">
                    <i class="fas fa-arrow-down text-blue-600 text-xl"></i>
                </div>
            </div>
            <p class="text-sm text-gray-500 mt-2">Single transaction</p>
        </div>
    </div>

    <!-- Replace the Charts section with this -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
    <!-- Spending Patterns by Day -->
    <div class="bg-white rounded-lg shadow-lg p-6">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-bold">Spending Patterns by Day</h3>
            <i class="fas fa-calendar-week text-indigo-600"></i>
        </div>
        <div class="space-y-4">
            <?php foreach($spending_patterns as $pattern): ?>
                <div class="border-b pb-3">
                    <div class="flex justify-between items-center mb-2">
                        <span class="font-medium"><?php echo $pattern['day_of_week']; ?></span>
                        <span class="text-indigo-600 font-bold">$<?php echo number_format($pattern['total_amount'], 2); ?></span>
                    </div>
                    <div class="grid grid-cols-2 gap-4 text-sm text-gray-600">
                        <div>Transactions: <?php echo $pattern['transaction_count']; ?></div>
                        <div>Avg: $<?php echo number_format($pattern['avg_amount'], 2); ?></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Expense Size Analysis -->
    <div class="bg-white rounded-lg shadow-lg p-6">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-bold">Expense Size Analysis</h3>
            <i class="fas fa-chart-bar text-indigo-600"></i>
        </div>
        <div class="space-y-4">
            <?php foreach($expense_ranges as $range): ?>
                <div class="border-b pb-3">
                    <div class="flex justify-between items-center mb-2">
                        <span class="font-medium"><?php echo $range['range_label']; ?></span>
                        <span class="text-indigo-600 font-bold"><?php echo $range['count']; ?> expenses</span>
                    </div>
                    <div class="grid grid-cols-2 gap-4 text-sm text-gray-600">
                        <div>Total: $<?php echo number_format($range['total'], 2); ?></div>
                        <div>Avg: $<?php echo number_format($range['average'], 2); ?></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- Print Button -->
<!-- Removed -->

<!-- Print Styles -->
<!-- Removed -->

<script>
function printReport() {
    // Removed
}

function initializeScripts() {
    // Removed
}
</script>

<script>
// Initialize date pickers
flatpickr("#start_date", {
    dateFormat: "Y-m-d",
    maxDate: "today"
});

flatpickr("#end_date", {
    dateFormat: "Y-m-d",
    maxDate: "today"
});

// Category Chart
const categoryData = <?php echo json_encode($expenses_by_category); ?>;
new Chart(document.getElementById('categoryChart'), {
    type: 'doughnut',
    data: {
        labels: categoryData.map(item => item.name),
        datasets: [{
            data: categoryData.map(item => item.total),
            backgroundColor: categoryData.map(item => item.color),
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'right'
            }
        },
        animation: {
            animateScale: true,
            animateRotate: true
        }
    }
});

// Trend Chart
const trendData = <?php echo json_encode($daily_expenses); ?>;
new Chart(document.getElementById('trendChart'), {
    type: 'line',
    data: {
        labels: trendData.map(item => new Date(item.date).toLocaleDateString()),
        datasets: [{
            label: 'Daily Expenses',
            data: trendData.map(item => item.total),
            borderColor: '#4F46E5',
            backgroundColor: 'rgba(79, 70, 229, 0.1)',
            fill: true,
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: false
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: value => '$' + value
                }
            }
        },
        animation: {
            duration: 2000,
            easing: 'easeInOutQuart'
        }
    }
});
</script>

<?php require_once 'includes/footer.php'; ?>
